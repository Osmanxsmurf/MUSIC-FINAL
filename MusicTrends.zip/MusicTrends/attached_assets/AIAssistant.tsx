import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sparkles, Send, User, Headphones, RefreshCw } from 'lucide-react';
import { AVAILABLE_MOODS, CHAT_SUGGESTIONS, DEFAULT_GREETING } from '@/lib/constants';
import { getTopTracksByTag } from '@/lib/lastfm-api';
import { searchYouTube } from '@/lib/youtube-api';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  className?: string;
}

export function AIAssistant({ className = '' }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: DEFAULT_GREETING,
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Mesajların en altına otomatik kaydırma
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  // Mesaj gönderme
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!inputMessage.trim()) return;
    
    // Kullanıcı mesajını ekle
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);
    
    try {
      // Asistan yanıtını oluştur
      const response = await generateResponse(inputMessage, messages);
      
      // Asistan mesajını ekle
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Yanıt oluşturulurken hata:', error);
      
      // Hata mesajı ekle
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Önerilen mesajı gönder
  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
    handleSendMessage();
  };
  
  // Yanıt oluşturma (basit yapay zeka simülasyonu)
  const generateResponse = async (message: string, history: Message[]): Promise<string> => {
    // Gerçek bir yapay zeka API'si kullanılabilir
    // Burada basit bir simülasyon yapıyoruz
    
    const lowercaseMessage = message.toLowerCase();
    
    // Ruh hali analizi
    const moodMatch = AVAILABLE_MOODS.find(mood => 
      lowercaseMessage.includes(mood.toLowerCase())
    );
    
    // Sanatçı adı arama
    const artistMatch = lowercaseMessage.match(/(?:(?:dinlemek|duymak|sevmek|önermek|öner) (?:istiyorum|isterim))? (.+?) (?:şarkıları|şarkısı|müziği|müzikleri)/i);
    
    // Tür arama
    const genreMatch = lowercaseMessage.match(/(?:(?:dinlemek|duymak|sevmek|önermek|öner) (?:istiyorum|isterim))? (.+?) (?:türünde|tarzında|gibi)/i);
    
    // Selamlama
    if (lowercaseMessage.includes('merhaba') || 
        lowercaseMessage.includes('selam') || 
        lowercaseMessage.includes('hey')) {
      return 'Merhaba! Size nasıl yardımcı olabilirim? Ruh halinize göre müzik önerileri almak ister misiniz?';
    }
    
    // Teşekkür
    if (lowercaseMessage.includes('teşekkür') || 
        lowercaseMessage.includes('sağol')) {
      return 'Rica ederim! Başka bir müzik önerisi ister misiniz?';
    }
    
    // Ruh haline göre öneri
    if (moodMatch) {
      try {
        // Last.fm API'den ruh haline göre şarkı al
        const tracks = await getTopTracksByTag(moodMatch.toLowerCase());
        
        if (tracks && tracks.length > 0) {
          const randomTracks = tracks
            .sort(() => 0.5 - Math.random())
            .slice(0, 3);
            
          return `${moodMatch} hissettiğinizi duyduğuma üzüldüm. İşte size bu ruh haline uygun birkaç şarkı önerisi:\n\n${
            randomTracks.map((track, index) => 
              `${index + 1}. "${track.name}" - ${track.artist}`
            ).join('\n')
          }\n\nUmarım bu şarkılar size iyi gelir!`;
        }
      } catch (error) {
        console.error('Şarkı önerileri alınırken hata:', error);
      }
    }
    
    // Sanatçıya göre öneri
    if (artistMatch && artistMatch[1]) {
      const artistName = artistMatch[1].trim();
      
      try {
        // YouTube API'den sanatçı videoları ara
        const videos = await searchYouTube(`${artistName} music`);
        
        if (videos && videos.length > 0) {
          const randomVideos = videos
            .sort(() => 0.5 - Math.random())
            .slice(0, 3);
            
          return `${artistName} harika bir seçim! İşte ${artistName} tarafından birkaç popüler şarkı:\n\n${
            randomVideos.map((video, index) => 
              `${index + 1}. "${video.title}"\n   🔗 https://www.youtube.com/watch?v=${video.videoId}`
            ).join('\n\n')
          }\n\nBunları beğendiniz mi?`;
        }
      } catch (error) {
        console.error('Sanatçı videoları aranırken hata:', error);
      }
    }
    
    // Türe göre öneri
    if (genreMatch && genreMatch[1]) {
      const genre = genreMatch[1].trim();
      
      try {
        // Last.fm API'den türe göre şarkı al
        const tracks = await getTopTracksByTag(genre.toLowerCase());
        
        if (tracks && tracks.length > 0) {
          const randomTracks = tracks
            .sort(() => 0.5 - Math.random())
            .slice(0, 4);
            
          return `${genre} türünde müzik harika bir seçim! İşte size bu türde birkaç öneri:\n\n${
            randomTracks.map((track, index) => 
              `${index + 1}. "${track.name}" - ${track.artist}`
            ).join('\n')
          }\n\nBu şarkıları dinlemek ister misiniz?`;
        }
      } catch (error) {
        console.error('Tür şarkıları alınırken hata:', error);
      }
    }
    
    // Genel öneri
    if (lowercaseMessage.includes('öner') || 
        lowercaseMessage.includes('tavsiye') || 
        lowercaseMessage.includes('ne dinle')) {
      try {
        // Last.fm API'den popüler şarkılar al
        const tracks = await getTopTracksByTag('popular');
        
        if (tracks && tracks.length > 0) {
          const randomTracks = tracks
            .sort(() => 0.5 - Math.random())
            .slice(0, 5);
            
          return `İşte size birkaç popüler şarkı önerisi:\n\n${
            randomTracks.map((track, index) => 
              `${index + 1}. "${track.name}" - ${track.artist}`
            ).join('\n')
          }\n\nBunlardan herhangi birini beğendiniz mi?`;
        }
      } catch (error) {
        console.error('Popüler şarkılar alınırken hata:', error);
      }
    }
    
    // Varsayılan yanıt
    return 'Size müzik konusunda yardımcı olmak isterim. Belirli bir ruh haline, sanatçıya veya türe göre öneriler almak ister misiniz?';
  };
  
  return (
    <Card className={`flex flex-col ${className}`}>
      <CardHeader className="px-4 py-3 border-b">
        <CardTitle className="text-lg flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Müzik Asistanı
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-y-auto p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div 
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <Avatar className="h-8 w-8 flex-shrink-0">
                  {message.role === 'assistant' ? (
                    <>
                      <AvatarImage src="/assistant-avatar.png" />
                      <AvatarFallback>
                        <Headphones className="h-5 w-5" />
                      </AvatarFallback>
                    </>
                  ) : (
                    <>
                      <AvatarImage src="/user-avatar.png" />
                      <AvatarFallback>
                        <User className="h-5 w-5" />
                      </AvatarFallback>
                    </>
                  )}
                </Avatar>
                
                <div 
                  className={`rounded-lg px-4 py-2 text-sm ${
                    message.role === 'assistant' 
                      ? 'bg-muted' 
                      : 'bg-primary text-primary-foreground'
                  }`}
                >
                  <div className="whitespace-pre-line">{message.content}</div>
                  <div 
                    className={`text-xs mt-1 ${
                      message.role === 'assistant' 
                        ? 'text-muted-foreground' 
                        : 'text-primary-foreground/70'
                    }`}
                  >
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex gap-3 max-w-[80%]">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    <Headphones className="h-5 w-5" />
                  </AvatarFallback>
                </Avatar>
                
                <div className="rounded-lg px-4 py-2 text-sm bg-muted">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span>Yanıt yazılıyor...</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-2 border-t">
        <div className="w-full space-y-4">
          {/* Önerilen mesajlar */}
          <div className="flex flex-wrap gap-2">
            {CHAT_SUGGESTIONS.slice(0, 3).map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleSuggestionClick(suggestion)}
                disabled={isLoading}
              >
                {suggestion}
              </Button>
            ))}
          </div>
          
          {/* Mesaj giriş formu */}
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              placeholder="Bir mesaj yazın..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              disabled={isLoading}
              className="flex-1"
            />
            <Button 
              type="submit" 
              size="icon"
              disabled={!inputMessage.trim() || isLoading}
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </CardFooter>
    </Card>
  );
}
