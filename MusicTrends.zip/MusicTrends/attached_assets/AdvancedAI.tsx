import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sparkles, Send, User, Headphones, RefreshCw, Brain, Eye, EyeOff } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AVAILABLE_MOODS, CHAT_SUGGESTIONS, DEFAULT_GREETING } from '@/lib/constants';
import { getTopTracksByTag, getSimilarTracks, getArtistInfo } from '@/lib/lastfm-api';
import { searchYouTube } from '@/lib/youtube-api';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  thinking?: string;
}

interface AdvancedAIProps {
  className?: string;
}

export default function AdvancedAI({ className = '' }: AdvancedAIProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: DEFAULT_GREETING,
      timestamp: new Date(),
      thinking: 'Kullanıcıyı karşılamak için standart bir selamlama mesajı gönderiyorum. Kullanıcının müzik tercihlerini öğrenmek için açık uçlu bir soru soruyorum.'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showThinking, setShowThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Mesajların en altına otomatik kaydırma
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  // Mesaj gönderme
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!inputMessage.trim()) return;
    
    // Kullanıcı mesajını ekle
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);
    
    try {
      // Asistan yanıtını oluştur
      const { response, thinking } = await generateAdvancedResponse(inputMessage, messages);
      
      // Asistan mesajını ekle
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
        thinking: thinking
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Yanıt oluşturulurken hata:', error);
      
      // Hata mesajı ekle
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date(),
        thinking: 'API çağrısı sırasında bir hata oluştu. Kullanıcıya genel bir hata mesajı gösteriyorum.'
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Önerilen mesajı gönder
  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
    handleSendMessage();
  };
  
  // Gelişmiş yanıt oluşturma
  const generateAdvancedResponse = async (message: string, history: Message[]): Promise<{ response: string, thinking: string }> => {
    // Düşünce sürecini başlat
    let thinking = 'Kullanıcının mesajını analiz ediyorum...\n';
    
    const lowercaseMessage = message.toLowerCase();
    
    // Ruh hali analizi
    thinking += '\n1. Ruh hali analizi yapıyorum:\n';
    const moodMatch = AVAILABLE_MOODS.find(mood => 
      lowercaseMessage.includes(mood.toLowerCase())
    );
    
    if (moodMatch) {
      thinking += `   ✓ Kullanıcı "${moodMatch}" ruh halinde olduğunu belirtiyor.\n`;
    } else {
      thinking += '   ✗ Belirli bir ruh hali tespit edilemedi.\n';
    }
    
    // Sanatçı adı arama
    thinking += '\n2. Sanatçı adı arıyorum:\n';
    const artistMatch = lowercaseMessage.match(/(?:(?:dinlemek|duymak|sevmek|önermek|öner) (?:istiyorum|isterim))? (.+?) (?:şarkıları|şarkısı|müziği|müzikleri)/i);
    
    if (artistMatch && artistMatch[1]) {
      thinking += `   ✓ Kullanıcı "${artistMatch[1]}" sanatçısıyla ilgileniyor.\n`;
    } else {
      thinking += '   ✗ Belirli bir sanatçı adı tespit edilemedi.\n';
    }
    
    // Tür arama
    thinking += '\n3. Müzik türü arıyorum:\n';
    const genreMatch = lowercaseMessage.match(/(?:(?:dinlemek|duymak|sevmek|önermek|öner) (?:istiyorum|isterim))? (.+?) (?:türünde|tarzında|gibi)/i);
    
    if (genreMatch && genreMatch[1]) {
      thinking += `   ✓ Kullanıcı "${genreMatch[1]}" türüyle ilgileniyor.\n`;
    } else {
      thinking += '   ✗ Belirli bir müzik türü tespit edilemedi.\n';
    }
    
    // Konuşma bağlamını analiz et
    thinking += '\n4. Konuşma bağlamını analiz ediyorum:\n';
    
    const lastAssistantMessage = [...history].reverse().find(m => m.role === 'assistant');
    
    if (lastAssistantMessage) {
      thinking += `   ✓ Son asistan mesajı: "${lastAssistantMessage.content.substring(0, 50)}..."\n`;
    } else {
      thinking += '   ✗ Önceki asistan mesajı bulunamadı.\n';
    }
    
    // Yanıt stratejisi belirleme
    thinking += '\n5. Yanıt stratejisi belirliyorum:\n';
    
    // Selamlama
    if (lowercaseMessage.includes('merhaba') || 
        lowercaseMessage.includes('selam') || 
        lowercaseMessage.includes('hey')) {
      thinking += '   → Kullanıcı selamlama yapıyor, karşılık vereceğim.\n';
      thinking += '   → Müzik tercihleri hakkında soru soracağım.\n';
      
      return {
        response: 'Merhaba! Size nasıl yardımcı olabilirim? Ruh halinize göre müzik önerileri almak ister misiniz?',
        thinking
      };
    }
    
    // Teşekkür
    if (lowercaseMessage.includes('teşekkür') || 
        lowercaseMessage.includes('sağol')) {
      thinking += '   → Kullanıcı teşekkür ediyor, kibarca karşılık vereceğim.\n';
      thinking += '   → Konuşmayı sürdürmek için yeni bir öneri sunacağım.\n';
      
      return {
        response: 'Rica ederim! Başka bir müzik önerisi ister misiniz? Belki farklı bir ruh haline veya türe göre öneriler sunabilirim.',
        thinking
      };
    }
    
    // Ruh haline göre öneri
    if (moodMatch) {
      thinking += `   → Kullanıcının "${moodMatch}" ruh haline göre öneri yapacağım.\n`;
      thinking += '   → Last.fm API\'den ruh haline uygun şarkılar arıyorum...\n';
      
      try {
        // Last.fm API'den ruh haline göre şarkı al
        const tracks = await getTopTracksByTag(moodMatch.toLowerCase());
        
        if (tracks && tracks.length > 0) {
          thinking += `   ✓ ${tracks.length} adet şarkı bulundu, rastgele 3 tanesini seçiyorum.\n`;
          
          const randomTracks = tracks
            .sort(() => 0.5 - Math.random())
            .slice(0, 3);
            
          thinking += '   → Şarkı listesini formatlanmış şekilde sunuyorum.\n';
          thinking += '   → Kullanıcının tepkisini ölçmek için soru ekliyorum.\n';
          
          return {
            response: `${moodMatch} hissettiğinizi duyduğuma üzüldüm. İşte size bu ruh haline uygun birkaç şarkı önerisi:\n\n${
              randomTracks.map((track, index) => 
                `${index + 1}. "${track.name}" - ${track.artist}`
              ).join('\n')
            }\n\nUmarım bu şarkılar size iyi gelir! Bu şarkılardan herhangi birini daha önce dinlediniz mi?`,
            thinking
          };
        } else {
          thinking += '   ✗ Şarkı bulunamadı, genel bir yanıt vereceğim.\n';
        }
      } catch (error) {
        thinking += `   ✗ API hatası: ${error}\n`;
        thinking += '   → Yedek plan: Genel bir yanıt vereceğim.\n';
      }
    }
    
    // Sanatçıya göre öneri
    if (artistMatch && artistMatch[1]) {
      const artistName = artistMatch[1].trim();
      
      thinking += `   → Kullanıcı "${artistName}" sanatçısıyla ilgileniyor.\n`;
      thinking += '   → Sanatçı hakkında bilgi ve popüler şarkılarını arayacağım...\n';
      
      try {
        // Sanatçı bilgilerini al
        const artistInfo = await getArtistInfo(artistName);
        
        if (artistInfo) {
          thinking += '   ✓ Sanatçı bilgileri bulundu.\n';
          thinking += '   → YouTube\'dan sanatçının videolarını arıyorum...\n';
          
          // YouTube API'den sanatçı videoları ara
          const videos = await searchYouTube(`${artistName} music`);
          
          if (videos && videos.length > 0) {
            thinking += `   ✓ ${videos.length} adet video bulundu, en popüler 3 tanesini seçiyorum.\n`;
            
            const topVideos = videos.slice(0, 3);
            
            thinking += '   → Video listesini formatlanmış şekilde sunuyorum.\n';
            thinking += '   → Kullanıcının tepkisini ölçmek için soru ekliyorum.\n';
            
            return {
              response: `${artistName} harika bir seçim! ${artistInfo.biography ? artistInfo.biography.substring(0, 100) + '...' : ''}\n\nİşte ${artistName} tarafından birkaç popüler şarkı:\n\n${
                topVideos.map((video, index) => 
                  `${index + 1}. "${video.title}"\n   🔗 https://www.youtube.com/watch?v=${video.videoId}`
                ).join('\n\n')
              }\n\nBunları beğendiniz mi? ${artistName}'a benzer başka sanatçılar da önerebilirim.`,
              thinking
            };
          } else {
            thinking += '   ✗ Video bulunamadı, sadece sanatçı bilgilerini sunacağım.\n';
            
            return {
              response: `${artistName} hakkında bilgi buldum! ${artistInfo.biography ? artistInfo.biography.substring(0, 200) + '...' : 'Maalesef detaylı biyografi bilgisi bulunamadı.'}\n\nBaşka bir sanatçı hakkında bilgi almak ister misiniz?`,
              thinking
            };
          }
        }
      } catch (error) {
        thinking += `   ✗ API hatası: ${error}\n`;
        thinking += '   → Yedek plan: Genel bir yanıt vereceğim.\n';
      }
    }
    
    // Türe göre öneri
    if (genreMatch && genreMatch[1]) {
      const genre = genreMatch[1].trim();
      
      thinking += `   → Kullanıcı "${genre}" türüyle ilgileniyor.\n`;
      thinking += '   → Last.fm API\'den bu türe ait şarkılar arıyorum...\n';
      
      try {
        // Last.fm API'den türe göre şarkı al
        const tracks = await getTopTracksByTag(genre.toLowerCase());
        
        if (tracks && tracks.length > 0) {
          thinking += `   ✓ ${tracks.length} adet şarkı bulundu, rastgele 4 tanesini seçiyorum.\n`;
          
          const randomTracks = tracks
            .sort(() => 0.5 - Math.random())
            .slice(0, 4);
            
          thinking += '   → Şarkı listesini formatlanmış şekilde sunuyorum.\n';
          thinking += '   → Kullanıcının tepkisini ölçmek için soru ekliyorum.\n';
          
          return {
            response: `${genre} türünde müzik harika bir seçim! İşte size bu türde birkaç öneri:\n\n${
              randomTracks.map((track, index) => 
                `${index + 1}. "${track.name}" - ${track.artist}`
              ).join('\n')
            }\n\nBu şarkıları dinlemek ister misiniz? Yoksa başka bir türde öneriler mi istersiniz?`,
            thinking
          };
        } else {
          thinking += '   ✗ Şarkı bulunamadı, genel bir yanıt vereceğim.\n';
        }
      } catch (error) {
        thinking += `   ✗ API hatası: ${error}\n`;
        thinking += '   → Yedek plan: Genel bir yanıt vereceğim.\n';
      }
    }
    
    // Genel öneri
    if (lowercaseMessage.includes('öner') || 
        lowercaseMessage.includes('tavsiye') || 
        lowercaseMessage.includes('ne dinle')) {
      thinking += '   → Kullanıcı genel bir öneri istiyor.\n';
      thinking += '   → Last.fm API\'den popüler şarkılar arıyorum...\n';
      
      try {
        // Last.fm API'den popüler şarkılar al
        const tracks = await getTopTracksByTag('popular');
        
        if (tracks && tracks.length > 0) {
          thinking += `   ✓ ${tracks.length} adet şarkı bulundu, rastgele 5 tanesini seçiyorum.\n`;
          
          const randomTracks = tracks
            .sort(() => 0.5 - Math.random())
            .slice(0, 5);
            
          thinking += '   → Şarkı listesini formatlanmış şekilde sunuyorum.\n';
          thinking += '   → Kullanıcının tepkisini ölçmek için soru ekliyorum.\n';
          
          return {
            response: `İşte size birkaç popüler şarkı önerisi:\n\n${
              randomTracks.map((track, index) => 
                `${index + 1}. "${track.name}" - ${track.artist}`
              ).join('\n')
            }\n\nBunlardan herhangi birini beğendiniz mi? Daha spesifik öneriler için ruh halinizi veya tercih ettiğiniz bir müzik türünü belirtebilirsiniz.`,
            thinking
          };
        } else {
          thinking += '   ✗ Şarkı bulunamadı, genel bir yanıt vereceğim.\n';
        }
      } catch (error) {
        thinking += `   ✗ API hatası: ${error}\n`;
        thinking += '   → Yedek plan: Genel bir yanıt vereceğim.\n';
      }
    }
    
    // Varsayılan yanıt
    thinking += '   → Belirli bir istek tespit edilemedi, genel bir yanıt vereceğim.\n';
    thinking += '   → Kullanıcıyı daha spesifik sorular sormaya yönlendireceğim.\n';
    
    return {
      response: 'Size müzik konusunda yardımcı olmak isterim. Belirli bir ruh haline, sanatçıya veya türe göre öneriler almak ister misiniz? Örneğin "Bugün enerjik hissediyorum, ne dinleyebilirim?" veya "Dua Lipa\'nın popüler şarkılarını önerir misin?" gibi sorular sorabilirsiniz.',
      thinking
    };
  };
  
  return (
    <Card className={`flex flex-col ${className}`}>
      <CardHeader className="px-4 py-3 border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Gelişmiş Müzik Asistanı
          </CardTitle>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowThinking(!showThinking)}
            className="h-8 gap-1 text-xs"
          >
            {showThinking ? (
              <>
                <EyeOff className="h-3 w-3" />
                <span>Düşünce Sürecini Gizle</span>
              </>
            ) : (
              <>
                <Eye className="h-3 w-3" />
                <span>Düşünce Sürecini Göster</span>
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-y-auto p-0">
        <Tabs defaultValue="chat" className="h-full">
          <TabsList className="w-full rounded-none border-b">
            <TabsTrigger value="chat" className="flex-1">Sohbet</TabsTrigger>
            {showThinking && (
              <TabsTrigger value="thinking" className="flex-1">Düşünce Süreci</TabsTrigger>
            )}
          </TabsList>
          
          <TabsContent value="chat" className="p-4 h-full overflow-y-auto">
            <div className="space-y-4">
              {messages.map((message) => (
                <div 
                  key={message.id}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      {message.role === 'assistant' ? (
                        <>
                          <AvatarImage src="/assistant-avatar.png" />
                          <AvatarFallback>
                            <Headphones className="h-5 w-5" />
                          </AvatarFallback>
                        </>
                      ) : (
                        <>
                          <AvatarImage src="/user-avatar.png" />
                          <AvatarFallback>
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        </>
                      )}
                    </Avatar>
                    
                    <div 
                      className={`rounded-lg px-4 py-2 text-sm ${
                        message.role === 'assistant' 
                          ? 'bg-muted' 
                          : 'bg-primary text-primary-foreground'
                      }`}
                    >
                      <div className="whitespace-pre-line">{message.content}</div>
                      <div 
                        className={`text-xs mt-1 ${
                          message.role === 'assistant' 
                            ? 'text-muted-foreground' 
                            : 'text-primary-foreground/70'
                        }`}
                      >
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex gap-3 max-w-[80%]">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        <Headphones className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="rounded-lg px-4 py-2 text-sm bg-muted">
                      <div className="flex items-center gap-2">
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span>Yanıt yazılıyor...</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </TabsContent>
          
          {showThinking && (
            <TabsContent value="thinking" className="p-4 h-full overflow-y-auto">
              <div className="space-y-4">
                {messages.filter(m => m.role === 'assistant' && m.thinking).map((message) => (
                  <div key={`thinking-${message.id}`} className="border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2 text-sm font-medium">
                      <Brain className="h-4 w-4 text-primary" />
                      <span>Asistan Düşünce Süreci</span>
                      <span className="text-xs text-muted-foreground ml-auto">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="whitespace-pre-line text-sm font-mono bg-muted p-3 rounded">
                      {message.thinking}
                    </div>
                    <div className="mt-3 pt-3 border-t">
                      <div className="text-xs text-muted-foreground mb-1">Sonuç:</div>
                      <div className="whitespace-pre-line text-sm">{message.content}</div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
      
      <CardFooter className="p-4 pt-2 border-t">
        <div className="w-full space-y-4">
          {/* Önerilen mesajlar */}
          <div className="flex flex-wrap gap-2">
            {CHAT_SUGGESTIONS.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleSuggestionClick(suggestion)}
                disabled={isLoading}
              >
                {suggestion}
              </Button>
            ))}
          </div>
          
          {/* Mesaj giriş formu */}
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              placeholder="Bir mesaj yazın..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              disabled={isLoading}
              className="flex-1"
            />
            <Button 
              type="submit" 
              size="icon"
              disabled={!inputMessage.trim() || isLoading}
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </CardFooter>
    </Card>
  );
}
