import { ChatMessage as AiMessage } from '@shared/schema';
import type { Song } from '@shared/schema';
import { DEFAULT_GREETING } from './constants';

// Gelişmiş AI yapısı için veri tipleri
export interface Topic {
  id: string;
  name: string;
  relevance: number; // 0-1 arası
  relatedTopics: string[];
  description: string;
}

export interface MusicalPreference {
  artist?: string;
  genre?: string;
  mood?: string;
  era?: string;
  confidence: number; // 0-1 arası
  source: string; // "explicit" - kullanıcının açıkça belirttiği, "implicit" - çıkarım yapılan
  lastMentioned: Date;
}

export interface FeelingAnalysis {
  primary: string;
  secondary?: string;
  intensity: number; // 0-1 arası
  confidence: number; // 0-1 arası
}

export interface BrainState {
  activeTopics: Topic[];
  userPreferences: MusicalPreference[];
  currentFeeling: FeelingAnalysis | null;
  conversationHistory: {
    messageCount: number;
    topicChanges: number;
    intensity: number; // 0-1 arası genel duygusal yoğunluk
    lastMusicReceivedFeedback: string;
  };
  knowledgeBase: {
    artistsKnown: string[];
    genresKnown: string[];
    moodsKnown: string[];
    eraKnown: string[];
  };
}

export interface SuperAIResponse {
  text: string;
  recommendations?: Song[];
  followUpQuestions?: string[];
  brainState?: BrainState;
}

// Temel NLP analizi
export function analyzeMessage(message: string, history: AiMessage[]): BrainState {
  // Başlangıç durumu
  const initialState: BrainState = {
    activeTopics: [],
    userPreferences: [],
    currentFeeling: null,
    conversationHistory: {
      messageCount: history.length,
      topicChanges: 0,
      intensity: 0.5,
      lastMusicReceivedFeedback: ''
    },
    knowledgeBase: {
      artistsKnown: ['Tarkan', 'Dua Lipa', 'The Weeknd', 'Sezen Aksu', 'MFÖ', 'Coldplay', 'Imagine Dragons'],
      genresKnown: ['pop', 'rock', 'jazz', 'klasik', 'hiphop', 'elektronik', 'metal', 'türkü', 'indie'],
      moodsKnown: ['mutlu', 'hüzünlü', 'enerjik', 'sakin', 'romantik', 'nostaljik', 'heyecanlı'],
      eraKnown: ['80ler', '90lar', '2000ler', '2010lar', 'yeni', 'eski']
    }
  };

  // 1. Konu Analizi
  const topics = extractTopics(message);
  initialState.activeTopics = topics;

  // 2. Müzikal tercihler
  const preferences = extractMusicalPreferences(message, history);
  initialState.userPreferences = preferences;

  // 3. Duygu Analizi
  const feeling = analyzeFeeling(message);
  initialState.currentFeeling = feeling;

  // 4. Konuşma dinamiği analizi
  const updatedHistory = analyzeConversationDynamics(history);
  initialState.conversationHistory = updatedHistory;

  return initialState;
}

// Konu çıkarma algoritması
function extractTopics(message: string): Topic[] {
  const topics: Topic[] = [];
  
  // Müzik ile ilgili popüler konu grupları
  const topicGroups = {
    artist: ['sanatçı', 'şarkıcı', 'grup', 'müzisyen', 'vokalist'],
    genre: ['tür', 'genre', 'tarz', 'pop', 'rock', 'jazz', 'klasik', 'hiphop', 'rap'],
    mood: ['ruh hali', 'mood', 'hissetmek', 'mutlu', 'üzgün', 'enerjik', 'sakin', 'romantik'],
    era: ['dönem', 'yıl', '80ler', '90lar', '2000ler', 'eski', 'yeni', 'retro', 'modern'],
    activity: ['çalışma', 'uyku', 'parti', 'egzersiz', 'spor', 'yürüyüş', 'koşu', 'dinlenme'],
    recommendation: ['öneri', 'tavsiye', 'öner', 'bul', 'keşfet', 'beğen', 'beğenebilir'],
    information: ['bilgi', 'ne', 'nedir', 'kim', 'ne zaman', 'nasıl', 'hakkında', 'albüm', 'şarkı', 'popüler']
  };
  
  // Mesajdaki kelimeleri analiz et
  const words = message.toLowerCase().split(/\s+/);
  
  // Her kategori için kontrol
  Object.entries(topicGroups).forEach(([category, keywords], index) => {
    // Bu kategoriden herhangi bir kelime var mı?
    const matchedKeywords = keywords.filter(keyword => 
      words.some(word => word.includes(keyword) || keyword.includes(word))
    );
    
    if (matchedKeywords.length > 0) {
      // Eşleşen kelimeler varsa, bir konu oluştur
      const relevance = Math.min(matchedKeywords.length / 3, 1); // En fazla 1 olacak şekilde
      
      topics.push({
        id: `topic-${index}`,
        name: category,
        relevance,
        relatedTopics: Object.keys(topicGroups).filter(k => k !== category && Math.random() > 0.7),
        description: `Kullanıcı ${category} hakkında konuşuyor gibi görünüyor.`
      });
    }
  });
  
  // Özel sanatçı/tür isimleri için kontrol
  const potentialArtists = ['tarkan', 'dua lipa', 'sezen aksu', 'coldplay', 'imagine dragons'];
  potentialArtists.forEach(artist => {
    if (message.toLowerCase().includes(artist)) {
      topics.push({
        id: `artist-${artist}`,
        name: 'artist',
        relevance: 0.9,
        relatedTopics: ['recommendation', 'information'],
        description: `Kullanıcı ${artist} hakkında konuşuyor.`
      });
    }
  });
  
  return topics;
}

// Müzikal tercihleri çıkarma
function extractMusicalPreferences(message: string, history: AiMessage[]): MusicalPreference[] {
  const preferences: MusicalPreference[] = [];
  const lowerMessage = message.toLowerCase();
  
  // 1. Sanatçı tercihleri
  const potentialArtists = [
    'tarkan', 'dua lipa', 'the weeknd', 'sezen aksu', 'mfö', 'coldplay', 'imagine dragons'
  ];
  
  potentialArtists.forEach(artist => {
    if (lowerMessage.includes(artist)) {
      // Sevme ifadelerini ara
      const likePatterns = ['sev', 'beğen', 'dinle', 'hoşlan', 'güzel', 'harika'];
      const dislikePatterns = ['sevme', 'beğenme', 'hoşlanma', 'kötü', 'berbat'];
      
      let isLiked = likePatterns.some(pattern => lowerMessage.includes(pattern));
      let isDisliked = dislikePatterns.some(pattern => lowerMessage.includes(pattern));
      
      // Eğer açık bir tercih belirtilmemişse, muhtemelen ilgileniyordur
      const confidence = isLiked ? 0.9 : (isDisliked ? 0.1 : 0.7);
      
      preferences.push({
        artist,
        confidence,
        source: 'explicit',
        lastMentioned: new Date()
      });
    }
  });
  
  // 2. Tür tercihleri
  const genres = ['pop', 'rock', 'jazz', 'klasik', 'hiphop', 'elektronik', 'metal', 'türkü'];
  genres.forEach(genre => {
    if (lowerMessage.includes(genre)) {
      preferences.push({
        genre,
        confidence: 0.8,
        source: 'explicit',
        lastMentioned: new Date()
      });
    }
  });
  
  // 3. Ruh hali tercihleri
  const moods = ['mutlu', 'hüzünlü', 'enerjik', 'sakin', 'romantik', 'nostaljik', 'melankoli'];
  moods.forEach(mood => {
    if (lowerMessage.includes(mood) || (mood === 'mutlu' && lowerMessage.includes('keyif'))) {
      preferences.push({
        mood,
        confidence: lowerMessage.includes('hisset') ? 0.95 : 0.8,
        source: 'explicit',
        lastMentioned: new Date()
      });
    }
  });
  
  // 4. Dönem/yıl tercihleri
  const eras = ['80', '90', '2000', 'retro', 'yeni', 'modern', 'eski'];
  eras.forEach(era => {
    if (lowerMessage.includes(era)) {
      preferences.push({
        era: `${era}${era.length <= 2 ? 'ler' : ''}`, // 80 -> 80ler
        confidence: 0.85,
        source: 'explicit',
        lastMentioned: new Date()
      });
    }
  });
  
  // 5. Geçmiş mesajlardan çıkarım yap
  if (history.length > 0) {
    const userMessages = history
      .filter(msg => msg.role === 'user')
      .map(msg => msg.content.toLowerCase());
    
    // Son 3 mesajı kontrol et
    userMessages.slice(-3).forEach(msg => {
      // Sanatçı, tür vb. analizi tekrar yap ama daha düşük güven skoruyla
      potentialArtists.forEach(artist => {
        if (msg.includes(artist) && !preferences.some(p => p.artist === artist)) {
          preferences.push({
            artist,
            confidence: 0.6,
            source: 'implicit',
            lastMentioned: new Date()
          });
        }
      });
    });
  }
  
  return preferences;
}

// Duygu analizi
function analyzeFeeling(message: string): FeelingAnalysis | null {
  const lowerMessage = message.toLowerCase();
  
  // Temel duygu sözlüğü
  const emotionKeywords = {
    'mutlu': ['mutlu', 'neşeli', 'keyifli', 'sevinçli', 'harika', 'güzel', 'pozitif'],
    'hüzünlü': ['üzgün', 'hüzünlü', 'melankolik', 'mutsuz', 'kederli', 'acı', 'kötü'],
    'öfkeli': ['kızgın', 'öfkeli', 'sinirli', 'bıktım', 'nefret'],
    'sakin': ['sakin', 'huzurlu', 'dingin', 'rahat', 'gevşek', 'dinlenmek'],
    'heyecanlı': ['heyecanlı', 'coşkulu', 'enerjik', 'aktif', 'motivasyonlu'],
    'yorgun': ['yorgun', 'bitkin', 'uykulu', 'tükenmiş', 'bezgin'],
    'kaygılı': ['endişeli', 'kaygılı', 'gergin', 'stresli', 'tedirgin']
  };
  
  // Duygu yoğunluk göstergeleri
  const intensityMarkers = {
    high: ['çok', 'aşırı', 'oldukça', 'gerçekten', 'son derece', '!'],
    low: ['biraz', 'az', 'hafif', 'kısmen']
  };
  
  // Duygusal ifadeleri analiz et
  let maxMatches = 0;
  let primaryEmotion = '';
  
  Object.entries(emotionKeywords).forEach(([emotion, keywords]) => {
    const matches = keywords.filter(word => lowerMessage.includes(word)).length;
    if (matches > maxMatches) {
      maxMatches = matches;
      primaryEmotion = emotion;
    }
  });
  
  // Eğer bir duygu tespit edilmediyse null döndür
  if (maxMatches === 0) {
    return null;
  }
  
  // Yoğunluk analizi
  let intensity = 0.5; // Varsayılan orta seviye
  const hasHighIntensity = intensityMarkers.high.some(marker => lowerMessage.includes(marker));
  const hasLowIntensity = intensityMarkers.low.some(marker => lowerMessage.includes(marker));
  
  if (hasHighIntensity) {
    intensity = 0.8;
  } else if (hasLowIntensity) {
    intensity = 0.3;
  }
  
  // Ünlem sayısı yoğunluğu artırır
  const exclamationCount = (lowerMessage.match(/!/g) || []).length;
  intensity = Math.min(intensity + (exclamationCount * 0.1), 1.0);
  
  // İkincil duygu analizi
  let secondaryEmotion: string | undefined;
  let secondaryMatches = 0;
  
  Object.entries(emotionKeywords).forEach(([emotion, keywords]) => {
    if (emotion !== primaryEmotion) {
      const matches = keywords.filter(word => lowerMessage.includes(word)).length;
      if (matches > secondaryMatches) {
        secondaryMatches = matches;
        secondaryEmotion = emotion;
      }
    }
  });
  
  // Güven skoru hesaplama
  let confidence = 0.5;
  confidence += (maxMatches * 0.1); // Her eşleşme güveni artırır
  confidence += (exclamationCount * 0.05); // Ünlemler güveni biraz artırır
  confidence = Math.min(confidence, 0.95); // En fazla 0.95 güven
  
  return {
    primary: primaryEmotion,
    secondary: secondaryMatches > 0 ? secondaryEmotion : undefined,
    intensity,
    confidence
  };
}

// Konuşma dinamiği analizi
function analyzeConversationDynamics(history: AiMessage[]): BrainState['conversationHistory'] {
  const dynamics = {
    messageCount: history.length,
    topicChanges: 0,
    intensity: 0.5,
    lastMusicReceivedFeedback: ''
  };
  
  if (history.length < 2) {
    return dynamics;
  }
  
  // Konu değişiklikleri analizi
  const userMessages = history.filter(msg => msg.role === 'user');
  let previousTopics: Topic[] = [];
  
  userMessages.forEach(msg => {
    const currentTopics = extractTopics(msg.content);
    
    // Önceki konularla ne kadar örtüşüyor?
    const topicOverlap = previousTopics.some(prevTopic => 
      currentTopics.some(currTopic => currTopic.name === prevTopic.name)
    );
    
    if (!topicOverlap && previousTopics.length > 0) {
      dynamics.topicChanges++;
    }
    
    previousTopics = currentTopics;
  });
  
  // Duygusal yoğunluk analizi
  const recentMessages = userMessages.slice(-3);
  let totalIntensity = 0;
  let intensityMeasurements = 0;
  
  recentMessages.forEach(msg => {
    const feeling = analyzeFeeling(msg.content);
    if (feeling) {
      totalIntensity += feeling.intensity;
      intensityMeasurements++;
    }
  });
  
  if (intensityMeasurements > 0) {
    dynamics.intensity = totalIntensity / intensityMeasurements;
  }
  
  // Müzik geri bildirim analizi
  const recentUserMessages = userMessages.slice(-2);
  const assistantMessages = history.filter(msg => msg.role === 'assistant').slice(-2);
  
  // Asistan müzik önerdiyse ve kullanıcı yanıt verdiyse
  if (assistantMessages.length > 0 && recentUserMessages.length > 0) {
    const lastAssistantMsg = assistantMessages[assistantMessages.length - 1].content.toLowerCase();
    const lastUserMsg = recentUserMessages[recentUserMessages.length - 1].content.toLowerCase();
    
    // Asistan müzik önerdiyse
    if (lastAssistantMsg.includes('öner') || lastAssistantMsg.includes('dinle')) {
      // Kullanıcı tepkisi
      const positiveWords = ['teşekkür', 'sağol', 'iyi', 'güzel', 'harika', 'süper', 'beğen', 'hoş'];
      const negativeWords = ['kötü', 'beğenmedim', 'sevmedim', 'berbat', 'değiştir', 'başka'];
      
      const hasPositive = positiveWords.some(word => lastUserMsg.includes(word));
      const hasNegative = negativeWords.some(word => lastUserMsg.includes(word));
      
      if (hasPositive && !hasNegative) {
        dynamics.lastMusicReceivedFeedback = 'positive';
      } else if (hasNegative && !hasPositive) {
        dynamics.lastMusicReceivedFeedback = 'negative';
      } else if (hasPositive && hasNegative) {
        dynamics.lastMusicReceivedFeedback = 'neutral';
      }
    }
  }
  
  return dynamics;
}

// Yanıt oluşturma fonksiyonu
export function generateResponse(message: string, history: AiMessage[]): SuperAIResponse {
  // 1. Temel analiz
  const brainState = analyzeMessage(message, history);
  
  // 2. Yanıt metnini hazırla
  let responseText = '';
  
  // Son kullanıcı mesajını ve önceki asistan mesajını al
  const lastUserMessage = message;
  const previousAssistantMessage = history
    .filter(msg => msg.role === 'assistant')
    .pop()?.content || '';
  
  // 3. Yanıt oluşturma stratejisi seç
  
  // a. Eğer kullanıcı duygu belirtiyorsa
  if (brainState.currentFeeling) {
    const { primary, intensity } = brainState.currentFeeling;
    
    const feelingResponses: Record<string, string[]> = {
      'mutlu': [
        'Mutlu olduğunuzu duymak harika! Size enerjik müzikler önerebilirim.',
        'Keyfinizi yükseltecek şarkılar dinlemek ister misiniz?',
        'Bu güzel ruh halinizi sürdürecek neşeli şarkılar önerebilirim.'
      ],
      'hüzünlü': [
        'Üzgün hissettiğinizi görüyorum. Sizi rahatlatacak müzikler önerebilirim.',
        'Bu duygularınıza eşlik edecek veya sizi sakinleştirecek şarkılar mı tercih edersiniz?',
        'Hüzünlü hissettiğinizde dinlemek istediğiniz belirli bir sanatçı var mı?'
      ],
      'öfkeli': [
        'Biraz gergin görünüyorsunuz. Sakinleştirici müzikler mi yoksa bu enerjiyi dışa vuracak parçalar mı istersiniz?',
        'Bu duygularınızı yansıtan güçlü parçalar önerebilirim.',
        'Kimi zaman müzik en iyi terapi olabilir. Size özel bir seçki hazırlayabilirim.'
      ],
      'sakin': [
        'Huzurlu bir ruh halinde olduğunuzu görmek güzel. Benzer tonda şarkılar önerebilirim.',
        'Bu sakin anınıza eşlik edecek dinlendirici müzikler ister misiniz?',
        'Dinginliğinizi devam ettirecek akustik veya klasik parçalar önerebilirim.'
      ],
      'heyecanlı': [
        'Enerji dolu görünüyorsunuz! Buna uygun hareketli şarkılar önerebilirim.',
        'Bu coşkuyu yansıtan dinamik şarkılar dinlemek ister misiniz?',
        'Heyecanınıza eşlik edecek ritimli parçalar seçebilirim.'
      ]
    };
    
    // Eğer duygu için özel yanıtlar varsa
    if (primary in feelingResponses) {
      const responses = feelingResponses[primary];
      responseText = responses[Math.floor(Math.random() * responses.length)];
      
      // Yoğunluğa göre yanıt şekillendirme
      if (intensity > 0.7) {
        responseText += ' Duygunuzun çok yoğun olduğunu görüyorum.';
      }
    }
  }
  
  // b. Eğer kullanıcı sanatçı/tür belirtiyorsa 
  const artistPrefs = brainState.userPreferences.filter(p => p.artist);
  const genrePrefs = brainState.userPreferences.filter(p => p.genre);
  
  if (artistPrefs.length > 0) {
    const artistName = artistPrefs[0].artist;
    responseText = responseText || `${artistName} dinlemek istediğinizi görüyorum. Size bu sanatçının şarkılarını bulabilirim.`;
  } else if (genrePrefs.length > 0) {
    const genreName = genrePrefs[0].genre;
    responseText = responseText || `${genreName} türünde müzik dinlemek istediğinizi anlıyorum. Size bu tarzda şarkılar önerebilirim.`;
  }
  
  // c. Eğer kullanıcı soru soruyorsa
  if (lastUserMessage.includes('?')) {
    if (lastUserMessage.toLowerCase().includes('öneri') || lastUserMessage.toLowerCase().includes('tavsiye')) {
      responseText = responseText || 'Size müzik önerileri sunmaktan memnuniyet duyarım. Hangi tarz müzik dinlemeyi seversiniz?';
    } else if (lastUserMessage.toLowerCase().includes('nasıl')) {
      responseText = responseText || 'Size müzik konusunda yardımcı olmak için buradayım. Şarkı önerisi, sanatçı bilgisi veya ruh halinize uygun müzikler için bana sorun.';
    }
  }
  
  // d. Hiçbir özel durum tespit edilmediyse
  if (!responseText) {
    const defaultResponses = [
      'Size müzik konusunda nasıl yardımcı olabilirim? Belirli bir sanatçı mı arıyorsunuz, yoksa ruh halinize uygun öneriler mi istersiniz?',
      'Müzik zevkiniz hakkında daha fazla bilgi edinmek isterim. Hangi tür müzikleri dinlemeyi seversiniz?',
      'Bugün size nasıl yardımcı olabilirim? Ruh halinize göre şarkılar önerebilir veya sevdiğiniz sanatçıları bulabilirim.'
    ];
    
    responseText = defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  }
  
  // 4. Takip soruları oluştur
  const followUpQuestions = generateFollowUpQuestions(brainState);
  
  // 5. Uygun şarkı önerileri oluştur (burada sadece bir simülasyon)
  const recommendations: Song[] = [];
  
  // 6. Final yanıtı döndür
  return {
    text: responseText,
    recommendations,
    followUpQuestions,
    brainState
  };
}

// Takip soruları oluşturma
function generateFollowUpQuestions(brainState: BrainState): string[] {
  const questions: string[] = [];
  
  // Kategorilere göre sorular
  const questionsByCategory: Record<string, string[]> = {
    artist: [
      'Başka hangi sanatçıları seviyorsunuz?',
      'Bu sanatçının hangi şarkılarını en çok beğeniyorsunuz?',
      'Benzer tarzda başka sanatçılar önermemi ister misiniz?'
    ],
    genre: [
      'Bu tür dışında dinlediğiniz başka müzik türleri var mı?', 
      'Bu türde en sevdiğiniz sanatçı kim?',
      'Daha hareketli/sakin parçalar mı tercih edersiniz?'
    ],
    mood: [
      'Şu anki ruh haliniz nasıl?',
      'Dinlerken nasıl hissetmek istersiniz?',
      'Müziğin ruh halinizi nasıl etkilemesini istiyorsunuz?'
    ],
    recommendation: [
      'Önerdiğim şarkıları beğendiniz mi?',
      'Bu tarza benzer başka öneriler ister misiniz?',
      'Şarkı önerilerinde neye önem verirsiniz?'
    ]
  };
  
  // Aktif konulara göre sorular ekle
  brainState.activeTopics.forEach(topic => {
    if (topic.name in questionsByCategory && questions.length < 2) {
      const categoryQuestions = questionsByCategory[topic.name];
      const randomQuestion = categoryQuestions[Math.floor(Math.random() * categoryQuestions.length)];
      
      // Aynı soruyu ekleme
      if (!questions.includes(randomQuestion)) {
        questions.push(randomQuestion);
      }
    }
  });
  
  // Kullanıcı tercihleriyle ilgili sorular
  brainState.userPreferences.forEach(pref => {
    if (questions.length < 2) {
      if (pref.artist && !questions.some(q => q.includes(pref.artist!))) {
        questions.push(`${pref.artist} dışında başka hangi sanatçıları dinlemeyi seversiniz?`);
      } else if (pref.genre && !questions.some(q => q.includes(pref.genre!))) {
        questions.push(`${pref.genre} müziğin hangi özelliklerini beğeniyorsunuz?`);
      }
    }
  });
  
  // Eğer hala soru yoksa genel sorular ekle
  if (questions.length === 0) {
    questions.push('Hangi tür müzikleri dinlemeyi seversiniz?');
    questions.push('Belirli bir ruh haline uygun müzik önerisi ister misiniz?');
  }
  
  return questions.slice(0, 2); // En fazla 2 soru döndür
}

// Selamlama mesajı
export function getSmartWelcomeMessage(): string {
  return DEFAULT_GREETING + "\n\nHoş geldiniz! Size kişiselleştirilmiş müzik önerileri sunabilirim. Ruh halinizi, sevdiğiniz sanatçıları veya müzik tarzlarınızı paylaşarak başlayabilirsiniz.";
}
