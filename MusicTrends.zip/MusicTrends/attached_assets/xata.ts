import { AVAILABLE_MOODS } from './constants';

// Xata veritabanı için tip tanımlamaları
export interface Song {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  genre?: string[];
  mood?: string[];
  imageUrl?: string;
  releaseDate?: string;
  popularity?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  imageUrl?: string;
  preferences?: {
    favoriteGenres?: string[];
    favoriteMoods?: string[];
    favoriteArtists?: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatMessage {
  id: string;
  userId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

// Simüle edilmiş veritabanı
const songs: Song[] = [
  {
    id: '1',
    title: 'Shape of You',
    artist: 'Ed Sheeran',
    album: '÷ (Divide)',
    duration: 233,
    genre: ['pop', 'dance'],
    mood: ['happy', 'energetic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273ba5db46f4b838ef6027e6f96',
    releaseDate: '2017-01-06',
    popularity: 95,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '2',
    title: 'Blinding Lights',
    artist: 'The Weeknd',
    album: 'After Hours',
    duration: 200,
    genre: ['pop', 'synth-pop', 'dance'],
    mood: ['energetic', 'nostalgic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36',
    releaseDate: '2019-11-29',
    popularity: 93,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '3',
    title: 'Someone Like You',
    artist: 'Adele',
    album: '21',
    duration: 285,
    genre: ['pop', 'soul'],
    mood: ['sad', 'emotional'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273295d32aaf86d6f768f8e9a11',
    releaseDate: '2011-01-24',
    popularity: 88,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '4',
    title: 'Dance Monkey',
    artist: 'Tones and I',
    album: 'The Kids Are Coming',
    duration: 210,
    genre: ['pop', 'dance'],
    mood: ['energetic', 'happy'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273c6f7af36ecb4b1f52bb6f50b',
    releaseDate: '2019-05-10',
    popularity: 90,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '5',
    title: 'Bohemian Rhapsody',
    artist: 'Queen',
    album: 'A Night at the Opera',
    duration: 354,
    genre: ['rock', 'progressive rock'],
    mood: ['epic', 'emotional'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273c8b444df094279e70d0ed856',
    releaseDate: '1975-10-31',
    popularity: 92,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '6',
    title: 'Billie Jean',
    artist: 'Michael Jackson',
    album: 'Thriller',
    duration: 294,
    genre: ['pop', 'dance', 'funk'],
    mood: ['energetic', 'groovy'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273de437d960dda1ac0a3586d97',
    releaseDate: '1982-01-02',
    popularity: 89,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '7',
    title: 'Bad Guy',
    artist: 'Billie Eilish',
    album: 'When We All Fall Asleep, Where Do We Go?',
    duration: 194,
    genre: ['pop', 'electropop'],
    mood: ['dark', 'confident'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273d55d10e0d95b43b9d310d760',
    releaseDate: '2019-03-29',
    popularity: 91,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '8',
    title: 'Imagine',
    artist: 'John Lennon',
    album: 'Imagine',
    duration: 183,
    genre: ['rock', 'pop'],
    mood: ['peaceful', 'reflective'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273d750ac13a56e8b26278a8e86',
    releaseDate: '1971-10-11',
    popularity: 85,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '9',
    title: 'Uptown Funk',
    artist: 'Mark Ronson ft. Bruno Mars',
    album: 'Uptown Special',
    duration: 270,
    genre: ['funk', 'pop', 'disco'],
    mood: ['energetic', 'happy'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273e419ccba0baa8bd3f3d7abf2',
    releaseDate: '2014-11-10',
    popularity: 87,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '10',
    title: 'Smells Like Teen Spirit',
    artist: 'Nirvana',
    album: 'Nevermind',
    duration: 301,
    genre: ['rock', 'grunge', 'alternative'],
    mood: ['angry', 'rebellious'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273e175a19e530c898d167d39bf',
    releaseDate: '1991-09-10',
    popularity: 86,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '11',
    title: 'Levitating',
    artist: 'Dua Lipa',
    album: 'Future Nostalgia',
    duration: 203,
    genre: ['pop', 'dance', 'disco'],
    mood: ['energetic', 'happy'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273bd26ede1ae69327010d49946',
    releaseDate: '2020-03-27',
    popularity: 89,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '12',
    title: 'Don\'t Start Now',
    artist: 'Dua Lipa',
    album: 'Future Nostalgia',
    duration: 183,
    genre: ['pop', 'dance', 'disco'],
    mood: ['confident', 'energetic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273bd26ede1ae69327010d49946',
    releaseDate: '2019-11-01',
    popularity: 88,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '13',
    title: 'Physical',
    artist: 'Dua Lipa',
    album: 'Future Nostalgia',
    duration: 194,
    genre: ['pop', 'dance', 'synth-pop'],
    mood: ['energetic', 'confident'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273bd26ede1ae69327010d49946',
    releaseDate: '2020-01-31',
    popularity: 86,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '14',
    title: 'Watermelon Sugar',
    artist: 'Harry Styles',
    album: 'Fine Line',
    duration: 174,
    genre: ['pop', 'rock'],
    mood: ['happy', 'summer'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273b46f74097655d7f353caab14',
    releaseDate: '2019-12-13',
    popularity: 87,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '15',
    title: 'Adore You',
    artist: 'Harry Styles',
    album: 'Fine Line',
    duration: 207,
    genre: ['pop', 'rock'],
    mood: ['romantic', 'happy'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273b46f74097655d7f353caab14',
    releaseDate: '2019-12-06',
    popularity: 85,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '16',
    title: 'Believer',
    artist: 'Imagine Dragons',
    album: 'Evolve',
    duration: 204,
    genre: ['pop rock', 'alternative'],
    mood: ['confident', 'energetic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273f1e056a6539fca9c5e5b490e',
    releaseDate: '2017-02-01',
    popularity: 86,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '17',
    title: 'Thunder',
    artist: 'Imagine Dragons',
    album: 'Evolve',
    duration: 187,
    genre: ['pop rock', 'alternative'],
    mood: ['confident', 'energetic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273f1e056a6539fca9c5e5b490e',
    releaseDate: '2017-04-27',
    popularity: 85,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '18',
    title: 'Stressed Out',
    artist: 'Twenty One Pilots',
    album: 'Blurryface',
    duration: 202,
    genre: ['alternative', 'indie pop'],
    mood: ['anxious', 'nostalgic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273de03bfc2991fd5bcfde65ba3',
    releaseDate: '2015-04-28',
    popularity: 84,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '19',
    title: 'Counting Stars',
    artist: 'OneRepublic',
    album: 'Native',
    duration: 257,
    genre: ['pop rock', 'alternative'],
    mood: ['hopeful', 'energetic'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273e9d2e8c0b5d1d0e4b2c63d1e',
    releaseDate: '2013-06-14',
    popularity: 83,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  },
  {
    id: '20',
    title: 'Memories',
    artist: 'Maroon 5',
    album: 'Memories',
    duration: 189,
    genre: ['pop', 'soft rock'],
    mood: ['nostalgic', 'reflective'],
    imageUrl: 'https://i.scdn.co/image/ab67616d0000b273b634a9f73fd5e6c3f829c8d5',
    releaseDate: '2019-09-20',
    popularity: 82,
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  }
];

// Kullanıcı verileri
const users: User[] = [
  {
    id: 'user1',
    name: 'Kullanıcı',
    email: 'user@example.com',
    preferences: {
      favoriteGenres: ['pop', 'rock', 'indie'],
      favoriteMoods: ['happy', 'energetic', 'peaceful'],
      favoriteArtists: ['Dua Lipa', 'Imagine Dragons', 'The Weeknd']
    },
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
  }
];

// Sohbet mesajları
const chatMessages: ChatMessage[] = [
  {
    id: 'msg1',
    userId: 'user1',
    content: 'Merhaba, bugün nasıl müzikler dinleyebilirim?',
    role: 'user',
    timestamp: new Date('2023-06-01T10:00:00')
  },
  {
    id: 'msg2',
    userId: 'user1',
    content: 'Merhaba! Bugün için size pop türünde enerjik şarkılar önerebilirim. Dua Lipa\'nın "Levitating" şarkısı veya The Weeknd\'in "Blinding Lights" şarkısı gibi parçalar nasıl olur?',
    role: 'assistant',
    timestamp: new Date('2023-06-01T10:00:05')
  }
];

// API fonksiyonları
export async function fetchSongs(limit = 10): Promise<Song[]> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(songs.slice(0, limit));
    }, 500);
  });
}

export async function fetchSongsByArtist(artistName: string): Promise<Song[]> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredSongs = songs.filter(
        song => song.artist.toLowerCase().includes(artistName.toLowerCase())
      );
      resolve(filteredSongs);
    }, 500);
  });
}

export async function fetchSongsByMood(mood: string): Promise<Song[]> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredSongs = songs.filter(
        song => song.mood?.some(m => m.toLowerCase() === mood.toLowerCase())
      );
      resolve(filteredSongs);
    }, 500);
  });
}

export async function fetchSongsByGenre(genre: string): Promise<Song[]> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredSongs = songs.filter(
        song => song.genre?.some(g => g.toLowerCase() === genre.toLowerCase())
      );
      resolve(filteredSongs);
    }, 500);
  });
}

export async function fetchSongById(id: string): Promise<Song | null> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      const song = songs.find(s => s.id === id) || null;
      resolve(song);
    }, 500);
  });
}

export async function fetchUserById(id: string): Promise<User | null> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      const user = users.find(u => u.id === id) || null;
      resolve(user);
    }, 500);
  });
}

export async function fetchChatHistory(userId = 'user1', limit = 20): Promise<ChatMessage[]> {
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      const userMessages = chatMessages
        .filter(msg => msg.userId === userId)
        .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
        .slice(0, limit);
      resolve(userMessages);
    }, 500);
  });
}

export async function sendChatMessage(content: string, userId = 'user1'): Promise<ChatMessage> {
  // Kullanıcı mesajını oluştur
  const userMessage: ChatMessage = {
    id: `msg${Date.now()}`,
    userId,
    content,
    role: 'user',
    timestamp: new Date()
  };
  
  // Asistan yanıtını oluştur (gerçek bir AI API'si kullanılabilir)
  const assistantMessage: ChatMessage = {
    id: `msg${Date.now() + 1}`,
    userId,
    content: generateSimpleResponse(content),
    role: 'assistant',
    timestamp: new Date(Date.now() + 1000)
  };
  
  // Mesajları kaydet (gerçek bir veritabanı kullanılabilir)
  chatMessages.push(userMessage);
  chatMessages.push(assistantMessage);
  
  // Gerçek bir API çağrısı yapılacak şekilde simüle ediliyor
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(assistantMessage);
    }, 1000);
  });
}

// Basit bir yanıt oluşturucu (gerçek bir AI API'si kullanılabilir)
function generateSimpleResponse(message: string): string {
  const lowercaseMessage = message.toLowerCase();
  
  // Ruh hali analizi
  const moodMatch = AVAILABLE_MOODS.find(mood => 
    lowercaseMessage.includes(mood.toLowerCase())
  );
  
  if (moodMatch) {
    return `${moodMatch} hissettiğinizi duydum. Size bu ruh haline uygun müzikler önerebilirim.`;
  }
  
  if (lowercaseMessage.includes('merhaba') || lowercaseMessage.includes('selam')) {
    return 'Merhaba! Size nasıl yardımcı olabilirim?';
  }
  
  if (lowercaseMessage.includes('teşekkür')) {
    return 'Rica ederim! Başka bir konuda yardıma ihtiyacınız olursa bana sorabilirsiniz.';
  }
  
  if (lowercaseMessage.includes('öner') || lowercaseMessage.includes('tavsiye')) {
    return 'Size birkaç popüler şarkı önerebilirim. Pop, rock veya indie türlerinden hangisini tercih edersiniz?';
  }
  
  return 'Size müzik konusunda nasıl yardımcı olabilirim?';
}
