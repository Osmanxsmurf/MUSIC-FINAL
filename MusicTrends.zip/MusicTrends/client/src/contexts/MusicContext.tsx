import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Song } from '@/lib/data';
import { getTopTracks } from '@/lib/lastfm-api';

// Müzik çalma bağlamı için tip tanımlaması
interface MusicContextType {
  currentSong: Song | null;
  queue: Song[];
  playHistory: Song[];
  isPlaying: boolean;
  currentTrack: any;
  
  // Metotlar
  playSong: (song: Song) => void;
  togglePlay: () => void;
  playNextSong: () => void;
  playPreviousSong: () => void;
  addToQueue: (song: Song) => void;
  clearQueue: () => void;
}

// Varsayılan bağlam değeri
const defaultContext: MusicContextType = {
  currentSong: null,
  queue: [],
  playHistory: [],
  isPlaying: false,
  currentTrack: null,
  
  playSong: () => {},
  togglePlay: () => {},
  playNextSong: () => {},
  playPreviousSong: () => {},
  addToQueue: () => {},
  clearQueue: () => {},
};

// Context oluşturma
const MusicContext = createContext<MusicContextType>(defaultContext);

// Context hook'u
export const useMusic = () => useContext(MusicContext);

// Provider komponenti
interface MusicProviderProps {
  children: ReactNode;
}

export const MusicProvider: React.FC<MusicProviderProps> = ({ children }) => {
  // State tanımlamaları
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [queue, setQueue] = useState<Song[]>([]);
  const [playHistory, setPlayHistory] = useState<Song[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<any>(null);
  
  // Örnek şarkıları yükleme
  useEffect(() => {
    async function loadInitialTracks() {
      try {
        const topTracks = await getTopTracks(5);
        if (topTracks && topTracks.length > 0) {
          // LastFM şarkılarını Song formatına dönüştür
          const songs = topTracks.map(track => ({
            id: `${track.name}-${track.artist}`,
            title: track.name,
            artist: track.artist,
            imageUrl: track.imageUrl,
            duration: track.duration,
            // Diğer özellikler
            toptags: { tag: track.tags.map(tag => ({ name: tag })) },
            createdAt: new Date(),
            updatedAt: new Date()
          }));
          
          setQueue(songs);
        }
      } catch (error) {
        console.error('Başlangıç şarkıları yüklenirken hata:', error);
      }
    }
    
    loadInitialTracks();
  }, []);
  
  // Şarkı çalma
  const playSong = (song: Song) => {
    if (currentSong) {
      // Önceki şarkıyı geçmişe ekle
      setPlayHistory(prev => [currentSong, ...prev.slice(0, 19)]);
    }
    
    setCurrentSong(song);
    setIsPlaying(true);
    setCurrentTrack(song);
    
    // Şarkı çalma geçmişi tarayıcı depolamasına kaydet
    try {
      const historyString = localStorage.getItem('musicPlayHistory');
      const history = historyString ? JSON.parse(historyString) : [];
      
      // Şarkıyı geçmişin başına ekleyip, uzunluğu sınırla
      const updatedHistory = [
        { 
          id: song.id,
          title: song.title || song.name,
          artist: song.artist,
          imageUrl: song.imageUrl,
          playedAt: new Date().toISOString() 
        },
        ...history.filter((s: any) => s.id !== song.id).slice(0, 19)
      ];
      
      localStorage.setItem('musicPlayHistory', JSON.stringify(updatedHistory));
    } catch (error) {
      console.error('Çalma geçmişi kaydedilirken hata:', error);
    }
  };
  
  // Çalmayı aç/kapat
  const togglePlay = () => {
    setIsPlaying(prev => !prev);
  };
  
  // Sonraki şarkı
  const playNextSong = () => {
    if (queue.length > 0) {
      // Sıradaki şarkıyı çal
      const nextSong = queue[0];
      const newQueue = queue.slice(1);
      
      playSong(nextSong);
      setQueue(newQueue);
    } else {
      // Sıra boşsa mevcut şarkıyı durdur
      setIsPlaying(false);
    }
  };
  
  // Önceki şarkı
  const playPreviousSong = () => {
    if (playHistory.length > 0) {
      const previousSong = playHistory[0];
      const newHistory = playHistory.slice(1);
      
      if (currentSong) {
        // Mevcut şarkıyı sıranın başına ekle
        setQueue(prev => [currentSong, ...prev]);
      }
      
      setCurrentSong(previousSong);
      setIsPlaying(true);
      setCurrentTrack(previousSong);
      setPlayHistory(newHistory);
    }
  };
  
  // Sıraya şarkı ekleme
  const addToQueue = (song: Song) => {
    setQueue(prev => [...prev, song]);
  };
  
  // Sırayı temizleme
  const clearQueue = () => {
    setQueue([]);
  };
  
  // Context değeri
  const value: MusicContextType = {
    currentSong,
    queue,
    playHistory,
    isPlaying,
    currentTrack,
    
    playSong,
    togglePlay,
    playNextSong,
    playPreviousSong,
    addToQueue,
    clearQueue,
  };
  
  return (
    <MusicContext.Provider value={value}>
      {children}
    </MusicContext.Provider>
  );
};