import { useQuery } from '@tanstack/react-query';
import { 
  getTopTracks, 
  getTrackInfo, 
  getArtistInfo, 
  getSimilarTracks, 
  getTopTracksByTag,
  LastfmTrack
} from '@/lib/lastfm-api';
import { useState, useEffect } from 'react';

// LastFM hook'ları
export const useTopTracks = () => {
  return useQuery({
    queryKey: ['topTracks'],
    queryFn: () => getTopTracks(10),
    staleTime: 1000 * 60 * 15, // 15 dakika için önbelleğe alma
  });
};

export const useTopArtists = () => {
  // Bu yanıt şimdilik sabit bir veri seti döner
  return useQuery({
    queryKey: ['topArtists'],
    queryFn: () => {
      return Promise.resolve({
        artists: {
          artist: [
            {
              name: 'Dua Lipa',
              listeners: '2500000',
              mbid: '6f798bd7-3a3e-45da-9f9a-4282e45c8cbb',
              url: 'https://www.last.fm/music/Dua+Lipa',
              streamable: '0',
              image: [
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/34s/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'small' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/64s/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'medium' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/174s/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'large' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/300x300/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'extralarge' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/300x300/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'mega' }
              ]
            },
            {
              name: 'The Weeknd',
              listeners: '2300000',
              mbid: 'c8b03190-306c-4120-bb0b-6f2ebfc06ea9',
              url: 'https://www.last.fm/music/The+Weeknd',
              streamable: '0',
              image: [
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/34s/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'small' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/64s/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'medium' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/174s/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'large' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/300x300/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'extralarge' },
                { '#text': 'https://lastfm.freetls.fastly.net/i/u/300x300/2a96cbd8b46e442fc41c2b86b821562f.png', size: 'mega' }
              ]
            }
          ]
        }
      });
    },
    staleTime: 1000 * 60 * 15, // 15 dakika için önbelleğe alma
  });
};

export const useTrackInfo = (artist: string, track: string) => {
  return useQuery({
    queryKey: ['trackInfo', artist, track],
    queryFn: () => getTrackInfo(artist, track),
    enabled: !!artist && !!track,
  });
};

export const useArtistInfo = (artist: string) => {
  return useQuery({
    queryKey: ['artistInfo', artist],
    queryFn: () => getArtistInfo(artist),
    enabled: !!artist,
  });
};

export const useSimilarTracks = (artist: string, track: string) => {
  return useQuery({
    queryKey: ['similarTracks', artist, track],
    queryFn: () => getSimilarTracks(artist, track),
    enabled: !!artist && !!track,
  });
};

export const useTracksByTag = (tag: string) => {
  return useQuery({
    queryKey: ['tracksByTag', tag],
    queryFn: () => getTopTracksByTag(tag),
    enabled: !!tag,
  });
};

// Kişiselleştirilmiş önerileri işlemek için özel hook
export const useRecommendedTracks = (mood?: string) => {
  const [recommendedTracks, setRecommendedTracks] = useState<LastfmTrack[]>([]);
  
  // Mood varsa ona göre şarkı öner
  const { data: moodTracks, isLoading: isMoodTracksLoading } = useTracksByTag(mood || 'happy');
  
  // Popüler şarkılar
  const { data: topTracks, isLoading: isTopTracksLoading } = useTopTracks();
  
  useEffect(() => {
    // Mood ya da popüler şarkıları kullan
    if (mood && moodTracks && moodTracks.length > 0) {
      setRecommendedTracks(moodTracks);
    } else if (topTracks && topTracks.length > 0) {
      setRecommendedTracks(topTracks);
    }
  }, [mood, moodTracks, topTracks]);
  
  return { 
    recommendedTracks, 
    isLoading: isMoodTracksLoading || isTopTracksLoading 
  };
};

// Arama yapmak için hook
export const useLastFmSearch = (query?: string) => {
  const [results, setResults] = useState<{
    tracks: LastfmTrack[];
    artists: any[];
    isLoading: boolean;
    error: string | null;
  }>({
    tracks: [],
    artists: [],
    isLoading: false,
    error: null
  });

  useEffect(() => {
    const searchMusic = async () => {
      if (!query || query.trim().length < 2) {
        setResults(prev => ({ ...prev, tracks: [], artists: [], isLoading: false }));
        return;
      }

      setResults(prev => ({ ...prev, isLoading: true, error: null }));

      try {
        // Şarkı araması yap
        let tracksPromise = getTopTracksByTag(query);

        // Tüm sonuçları topla
        const [tracks] = await Promise.all([tracksPromise]);

        // Sonuçları birleştir ve state'e ekle
        setResults({
          tracks: tracks || [],
          artists: [],
          isLoading: false,
          error: null
        });
      } catch (error) {
        console.error('Arama hatası:', error);
        setResults({
          tracks: [],
          artists: [],
          isLoading: false,
          error: 'Arama sırasında bir hata oluştu.'
        });
      }
    };

    // Search fonksiyonunu çağır
    const timer = setTimeout(() => {
      searchMusic();
    }, 500); // 500ms gecikme ile çalışır

    return () => clearTimeout(timer);
  }, [query]);

  return results;
};