import { useQuery } from '@tanstack/react-query';
import { fetchSongs, fetchSongsByArtist, fetchSongsByMood, fetchSongsByGenre, fetchSongById, fetchUserById, fetchChatHistory, Song } from '@/lib/xata';

// Hook'lar için tip tanımları
type UseQueryResult<T> = {
  data: T | undefined;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
};

/**
 * Tüm şarkıları getiren hook
 * @param limit Maksimum şarkı sayısı
 */
export function useSongs(limit = 10): UseQueryResult<Song[]> {
  const { data, isLoading, isError, error } = useQuery<Song[], Error>({
    queryKey: ['songs', limit],
    queryFn: () => fetchSongs(limit)
  });

  return { data, isLoading, isError, error };
}

/**
 * Belirli bir sanatçının şarkılarını getiren hook
 * @param artistName Sanatçı adı
 */
export function useSongsByArtist(artistName: string): UseQueryResult<Song[]> {
  const { data, isLoading, isError, error } = useQuery<Song[], Error>({
    queryKey: ['songs', 'artist', artistName],
    queryFn: () => fetchSongsByArtist(artistName),
    enabled: !!artistName
  });

  return { data, isLoading, isError, error };
}

/**
 * Belirli bir ruh haline göre şarkıları getiren hook
 * @param mood Ruh hali
 */
export function useSongsByMood(mood: string): UseQueryResult<Song[]> {
  const { data, isLoading, isError, error } = useQuery<Song[], Error>({
    queryKey: ['songs', 'mood', mood],
    queryFn: () => fetchSongsByMood(mood),
    enabled: !!mood
  });

  return { data, isLoading, isError, error };
}

/**
 * Belirli bir türe göre şarkıları getiren hook
 * @param genre Tür
 */
export function useSongsByGenre(genre: string): UseQueryResult<Song[]> {
  const { data, isLoading, isError, error } = useQuery<Song[], Error>({
    queryKey: ['songs', 'genre', genre],
    queryFn: () => fetchSongsByGenre(genre),
    enabled: !!genre
  });

  return { data, isLoading, isError, error };
}

/**
 * Belirli bir şarkıyı ID'sine göre getiren hook
 * @param id Şarkı ID'si
 */
export function useSongById(id: string): UseQueryResult<Song | null> {
  const { data, isLoading, isError, error } = useQuery<Song | null, Error>({
    queryKey: ['song', id],
    queryFn: () => fetchSongById(id),
    enabled: !!id
  });

  return { data, isLoading, isError, error };
}

/**
 * Belirli bir ruh hali, tür veya sanatçıya göre önerilen şarkıları getirir
 * @param mood Ruh hali (isteğe bağlı)
 * @param genre Tür (isteğe bağlı)
 * @param artist Sanatçı (isteğe bağlı)
 */
export function useRecommendedSongs(
  mood?: string, 
  genre?: string, 
  artist?: string
): UseQueryResult<Song[]> {
  // Parametrelerden hangisi varsa ona göre sorgu yapalım
  const queryFn = () => {
    if (mood) return fetchSongsByMood(mood);
    if (genre) return fetchSongsByGenre(genre);
    if (artist) return fetchSongsByArtist(artist);
    return fetchSongs(10); // Hiçbiri yoksa popüler şarkıları getirelim
  };
  
  const queryKey = ['songs', 'recommended', { mood, genre, artist }];
  
  const { data, isLoading, isError, error } = useQuery<Song[], Error>({
    queryKey,
    queryFn
  });

  return { data, isLoading, isError, error };
}