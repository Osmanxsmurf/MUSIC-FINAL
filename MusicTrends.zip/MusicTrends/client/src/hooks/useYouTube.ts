import { useQuery } from '@tanstack/react-query';
import { searchYouTube, getYouTubeVideoDetails } from '@/lib/api';

export function useYouTubeSearch(query: string, enabled = true) {
  return useQuery({
    queryKey: ['youtube', 'search', query],
    queryFn: () => searchYouTube(query),
    enabled: enabled && query.length > 2,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

export function useYouTubeVideo(videoId: string, enabled = true) {
  return useQuery({
    queryKey: ['youtube', 'video', videoId],
    queryFn: () => getYouTubeVideoDetails(videoId),
    enabled: enabled && !!videoId,
    staleTime: 1000 * 60 * 30, // 30 minutes
  });
}
