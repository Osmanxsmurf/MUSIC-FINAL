import { LastFmApiResponse, LastFmSearchResult, LastFmChartTopTracks, LastFmChartTopArtists, LastFmArtist, LastFmAlbum, LastFmTrack } from '@/types/lastfm';
import { YouTubeSearchListResponse, YouTubeVideoListResponse } from '@/types/youtube';

const LASTFM_API_KEY = import.meta.env.VITE_LASTFM_API_KEY || 'd30fafc9944e1f9fe3ae7bd3887e9b5';
const YOUTUBE_API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY || 'AIzaSyAzqsXjoQCFDi5c5Lf6Ilp9det-5lS5QCg';

const LASTFM_API_URL = 'https://ws.audioscrobbler.com/2.0/';
const YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3/';

export async function searchLastFm(query: string, type: 'artist' | 'album' | 'track' = 'track'): Promise<LastFmApiResponse<LastFmSearchResult>> {
  const method = `${type}.search`;
  const url = `${LASTFM_API_URL}?method=${method}&${type}=${encodeURIComponent(query)}&api_key=${LASTFM_API_KEY}&format=json`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error searching Last.fm:', error);
    throw error;
  }
}

export async function getTopTracks(): Promise<LastFmApiResponse<LastFmChartTopTracks>> {
  const url = `${LASTFM_API_URL}?method=chart.getTopTracks&api_key=${LASTFM_API_KEY}&format=json&limit=10`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting top tracks from Last.fm:', error);
    throw error;
  }
}

export async function getTopArtists(): Promise<LastFmApiResponse<LastFmChartTopArtists>> {
  const url = `${LASTFM_API_URL}?method=chart.getTopArtists&api_key=${LASTFM_API_KEY}&format=json&limit=10`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting top artists from Last.fm:', error);
    throw error;
  }
}

export async function getArtistInfo(artist: string): Promise<LastFmApiResponse<LastFmArtist>> {
  const url = `${LASTFM_API_URL}?method=artist.getInfo&artist=${encodeURIComponent(artist)}&api_key=${LASTFM_API_KEY}&format=json`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting artist info from Last.fm:', error);
    throw error;
  }
}

export async function getAlbumInfo(artist: string, album: string): Promise<LastFmApiResponse<LastFmAlbum>> {
  const url = `${LASTFM_API_URL}?method=album.getInfo&artist=${encodeURIComponent(artist)}&album=${encodeURIComponent(album)}&api_key=${LASTFM_API_KEY}&format=json`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting album info from Last.fm:', error);
    throw error;
  }
}

export async function getTrackInfo(artist: string, track: string): Promise<LastFmApiResponse<LastFmTrack>> {
  const url = `${LASTFM_API_URL}?method=track.getInfo&artist=${encodeURIComponent(artist)}&track=${encodeURIComponent(track)}&api_key=${LASTFM_API_KEY}&format=json`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting track info from Last.fm:', error);
    throw error;
  }
}

export async function getSimilarTracks(artist: string, track: string): Promise<LastFmApiResponse<LastFmTrack>> {
  const url = `${LASTFM_API_URL}?method=track.getSimilar&artist=${encodeURIComponent(artist)}&track=${encodeURIComponent(track)}&api_key=${LASTFM_API_KEY}&format=json&limit=10`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting similar tracks from Last.fm:', error);
    throw error;
  }
}

export async function searchYouTube(query: string): Promise<YouTubeSearchListResponse> {
  const url = `${YOUTUBE_API_URL}search?part=snippet&maxResults=5&q=${encodeURIComponent(query)}&type=video&key=${YOUTUBE_API_KEY}`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error searching YouTube:', error);
    throw error;
  }
}

export async function getYouTubeVideoDetails(videoId: string): Promise<YouTubeVideoListResponse> {
  const url = `${YOUTUBE_API_URL}videos?part=snippet,contentDetails,statistics&id=${videoId}&key=${YOUTUBE_API_KEY}`;
  
  try {
    const response = await fetch(url);
    return await response.json();
  } catch (error) {
    console.error('Error getting YouTube video details:', error);
    throw error;
  }
}
