import { Song, User, ChatMessage, fetchSongs, fetchSongsByArtist, fetchSongsByMood, fetchSongsByGenre, fetchSongById, fetchUserById, fetchChatHistory, sendChatMessage } from '../../../attached_assets/xata';

// Dışa aktarılan veri fonksiyonları
export {
  fetchSongs,
  fetchSongsByArtist, 
  fetchSongsByMood,
  fetchSongsByGenre,
  fetchSongById,
  fetchUserById,
  fetchChatHistory,
  sendChatMessage
};

// Tip tanımlamalarını da dışa aktar
export type { Song, User, ChatMessage };