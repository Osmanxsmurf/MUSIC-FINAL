// Xata için basitleştirilmiş HTTP istemci
// Doğrudan fetch API kullanarak veritabanına erişim sağlıyoruz

// Xata bağlantı bilgileri
const xataApiKey = import.meta.env.VITE_XATA_API_KEY;
const xataDatabaseURL = import.meta.env.VITE_XATA_DATABASE_URL;

// HTTP istekleri için temel fonksiyon
async function fetchFromXata(endpoint: string, options: RequestInit = {}) {
  const url = `${xataDatabaseURL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${xataApiKey}`,
    ...options.headers
  };

  try {
    const response = await fetch(url, {
      ...options,
      headers
    });

    if (!response.ok) {
      throw new Error(`Xata API error: ${response.status} ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Xata veri isteği hatası:', error);
    throw error;
  }
}

// Tip tanımlamaları
export interface Song {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  genre?: string[];
  mood?: string[];
  imageUrl?: string;
  releaseDate?: string;
  popularity?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  imageUrl?: string;
  preferences?: {
    favoriteGenres?: string[];
    favoriteMoods?: string[];
    favoriteArtists?: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatMessage {
  id: string;
  userId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

// Veritabanı işlemleri

// Şarkıları getir
export async function fetchSongs(limit = 10): Promise<Song[]> {
  try {
    // Xata API ile şarkıları çek
    const response = await fetchFromXata('/tables/songs/query', {
      method: 'POST',
      body: JSON.stringify({
        page: { size: limit },
        columns: ['*']
      })
    });
    
    return response.records as Song[];
  } catch (error) {
    console.error('Şarkılar getirilirken hata oluştu:', error);
    return []; 
  }
}

// Sanatçıya göre şarkıları getir
export async function fetchSongsByArtist(artistName: string): Promise<Song[]> {
  try {
    const response = await fetchFromXata('/tables/songs/query', {
      method: 'POST',
      body: JSON.stringify({
        filter: {
          artist: { $contains: artistName }
        },
        columns: ['*']
      })
    });
    
    return response.records as Song[];
  } catch (error) {
    console.error(`${artistName} sanatçısının şarkıları getirilirken hata oluştu:`, error);
    return [];
  }
}

// Ruh haline göre şarkıları getir
export async function fetchSongsByMood(mood: string): Promise<Song[]> {
  try {
    const response = await fetchFromXata('/tables/songs/query', {
      method: 'POST',
      body: JSON.stringify({
        filter: {
          mood: { $includes: mood }
        },
        columns: ['*']
      })
    });
    
    return response.records as Song[];
  } catch (error) {
    console.error(`${mood} ruh haline göre şarkılar getirilirken hata oluştu:`, error);
    return [];
  }
}

// Türe göre şarkıları getir
export async function fetchSongsByGenre(genre: string): Promise<Song[]> {
  try {
    const response = await fetchFromXata('/tables/songs/query', {
      method: 'POST',
      body: JSON.stringify({
        filter: {
          genre: { $includes: genre }
        },
        columns: ['*']
      })
    });
    
    return response.records as Song[];
  } catch (error) {
    console.error(`${genre} türüne göre şarkılar getirilirken hata oluştu:`, error);
    return [];
  }
}

// ID'ye göre şarkı getir
export async function fetchSongById(id: string): Promise<Song | null> {
  try {
    const response = await fetchFromXata(`/tables/songs/data/${id}`);
    return response as Song;
  } catch (error) {
    console.error(`${id} ID'sine sahip şarkı getirilirken hata oluştu:`, error);
    return null;
  }
}

// Kullanıcı getir
export async function fetchUserById(id: string): Promise<User | null> {
  try {
    const response = await fetchFromXata(`/tables/users/data/${id}`);
    return response as User;
  } catch (error) {
    console.error(`${id} ID'sine sahip kullanıcı getirilirken hata oluştu:`, error);
    return null;
  }
}

// Sohbet geçmişini getir
export async function fetchChatHistory(userId = 'user1', limit = 20): Promise<ChatMessage[]> {
  try {
    const response = await fetchFromXata('/tables/chatMessages/query', {
      method: 'POST',
      body: JSON.stringify({
        filter: { userId },
        sort: { timestamp: 'asc' },
        page: { size: limit },
        columns: ['*']
      })
    });
    
    return response.records as ChatMessage[];
  } catch (error) {
    console.error(`Sohbet geçmişi getirilirken hata oluştu:`, error);
    return [];
  }
}

// Sohbet mesajı gönder
export async function sendChatMessage(content: string, userId = 'user1'): Promise<ChatMessage> {
  try {
    // Kullanıcı mesajını oluştur
    const userMessage = {
      userId,
      content,
      role: 'user',
      timestamp: new Date().toISOString()
    };
    
    // Mesajı veritabanına ekle
    const response = await fetchFromXata('/tables/chatMessages/data', {
      method: 'POST',
      body: JSON.stringify(userMessage)
    });
    
    return response as ChatMessage;
  } catch (error) {
    console.error('Sohbet mesajı gönderilirken hata oluştu:', error);
    throw error;
  }
}