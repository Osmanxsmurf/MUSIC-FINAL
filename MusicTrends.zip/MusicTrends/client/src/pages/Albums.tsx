import React, { useEffect } from 'react';
import { useTopTracks } from '@/hooks/useLastFm';
import AlbumCard from '@/components/music/AlbumCard';
import { LastFmAlbum } from '@/types/lastfm';

const Albums = () => {
  const { data: topTracksData, isLoading } = useTopTracks();
  
  useEffect(() => {
    document.title = 'Müzik Asistanım - Albümler';
  }, []);
  
  // Create album objects from top tracks
  const albums: LastFmAlbum[] = [];
  const albumMap = new Map<string, LastFmAlbum>();
  
  if (topTracksData?.tracks?.track) {
    topTracksData.tracks.track.forEach(track => {
      if (track.album) {
        const key = `${track.album.title}-${track.artist.name}`;
        
        if (!albumMap.has(key) && track.album.image && track.album.image.length > 0) {
          const album: LastFmAlbum = {
            name: track.album.title,
            artist: track.artist.name,
            url: track.album.url,
            image: track.album.image,
            tracks: {
              track: [track]
            }
          };
          albumMap.set(key, album);
          albums.push(album);
        } else if (albumMap.has(key)) {
          const existingAlbum = albumMap.get(key)!;
          if (existingAlbum.tracks) {
            existingAlbum.tracks.track.push(track);
          } else {
            existingAlbum.tracks = { track: [track] };
          }
        }
      }
    });
  }
  
  return (
    <div className="p-4 pb-24">
      <h1 className="text-2xl font-bold mb-6">Albümler</h1>
      
      {/* Top Albums */}
      <section className="mb-8">
        <h2 className="text-xl font-bold mb-4">Popüler Albümler</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {isLoading ? (
            Array(10).fill(0).map((_, index) => (
              <div key={index} className="bg-card rounded-lg p-3 animate-pulse">
                <div className="aspect-square bg-muted rounded-md mb-3"></div>
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </div>
            ))
          ) : albums.length > 0 ? (
            albums.map((album, index) => (
              <AlbumCard key={index} album={album} />
            ))
          ) : (
            <p className="col-span-full text-center text-muted-foreground py-4">Albüm bilgileri bulunamadı.</p>
          )}
        </div>
      </section>
      
      {/* Genre Categories */}
      <section>
        <h2 className="text-xl font-bold mb-4">Müzik Türleri</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {['Pop', 'Rock', 'Hip-Hop', 'Elektronik', 'Caz', 'Klasik', 'R&B', 'Country'].map((genre, index) => (
            <div key={index} className="bg-card rounded-lg overflow-hidden group cursor-pointer">
              <div className="h-24 bg-gradient-to-r from-primary/40 to-accent/20 flex items-center justify-center relative group-hover:scale-105 transition-transform">
                <h3 className="text-xl font-bold">{genre}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Albums;
