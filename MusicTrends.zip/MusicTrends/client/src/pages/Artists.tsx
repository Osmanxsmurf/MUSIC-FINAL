import React, { useEffect } from 'react';
import { useTopArtists } from '@/hooks/useLastFm';
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Play, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLastFmSearch } from '@/hooks/useLastFm';
import { useMusic } from '@/contexts/MusicContext';

const Artists = () => {
  const { data: topArtistsData, isLoading: isLoadingArtists } = useTopArtists();
  const { playTrack } = useMusic();
  
  // Get top artists
  const topArtists = topArtistsData?.artists?.artist || [];
  
  useEffect(() => {
    document.title = 'Müzik Asistanım - Sanatçılar';
  }, []);
  
  // Play artist's top track
  const playTopTrack = async (artistName: string) => {
    // Search for artist's top tracks
    const { data } = await useLastFmSearch(artistName, 'track').refetch();
    
    // If we have results, play the first track
    if (data?.results?.trackmatches?.track && data.results.trackmatches.track.length > 0) {
      playTrack(data.results.trackmatches.track[0]);
    }
  };
  
  return (
    <div className="p-4 pb-24">
      <h1 className="text-2xl font-bold mb-6">Sanatçılar</h1>
      
      {/* Featured Artists */}
      <section className="mb-8">
        <h2 className="text-xl font-bold mb-4">Popüler Sanatçılar</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {isLoadingArtists ? (
            Array(10).fill(0).map((_, index) => (
              <div key={index} className="flex flex-col items-center animate-pulse">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-muted mb-3"></div>
                <div className="h-4 bg-muted rounded w-20 mb-1"></div>
                <div className="h-3 bg-muted rounded w-16"></div>
              </div>
            ))
          ) : (
            topArtists.slice(0, 10).map((artist, index) => (
              <div key={index} className="flex flex-col items-center group">
                <div className="relative mb-3">
                  <Avatar className="w-24 h-24 md:w-32 md:h-32 border-2 border-transparent group-hover:border-primary transition-colors">
                    <AvatarImage 
                      src={artist.image?.[3]['#text']} 
                      alt={artist.name} 
                    />
                    <AvatarFallback className="text-lg">{artist.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <Button 
                    size="icon"
                    className="absolute bottom-0 right-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity bg-primary text-white"
                    onClick={() => playTopTrack(artist.name)}
                  >
                    <Play className="h-4 w-4" />
                  </Button>
                </div>
                <h3 className="font-medium text-center truncate max-w-full">{artist.name}</h3>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Users className="w-3 h-3" /> 
                  {parseInt(artist.listeners || '0').toLocaleString()}
                </p>
              </div>
            ))
          )}
        </div>
      </section>
      
      {/* Recommended Artists */}
      <section>
        <h2 className="text-xl font-bold mb-4">Önerilen Sanatçılar</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {topArtists.slice(10, 16).map((artist, index) => (
            <div key={index} className="bg-card rounded-lg p-4 flex items-center gap-4 group hover:bg-secondary transition-colors">
              <Avatar className="w-16 h-16 border-2 border-transparent group-hover:border-primary transition-colors">
                <AvatarImage 
                  src={artist.image?.[2]['#text']} 
                  alt={artist.name} 
                />
                <AvatarFallback>{artist.name.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-medium truncate">{artist.name}</h3>
                <p className="text-xs text-muted-foreground mb-2">
                  {parseInt(artist.listeners || '0').toLocaleString()} dinleyici
                </p>
                <Button 
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => playTopTrack(artist.name)}
                >
                  <Play className="h-3 w-3 mr-1" />
                  Dinle
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Artists;
