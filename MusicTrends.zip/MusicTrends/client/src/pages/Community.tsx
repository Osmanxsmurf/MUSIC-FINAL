import React, { useState } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ActivityFeed } from '@/components/community/ActivityFeed';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { SearchIcon, UsersIcon, TrendingUpIcon, MusicIcon, Share2Icon } from 'lucide-react';

export default function Community() {
  const [post, setPost] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Simüle edilmiş popüler kullanıcılar
  const popularUsers = [
    { id: 'user1', name: 'Ahmet Yılmaz', username: 'ahmetyilmaz', imageUrl: 'https://randomuser.me/api/portraits/men/32.jpg', followers: 248 },
    { id: 'user2', name: 'Zeynep Kaya', username: 'zeynepkaya', imageUrl: 'https://randomuser.me/api/portraits/women/44.jpg', followers: 352 },
    { id: 'user3', name: 'Ozan Demir', username: 'ozandemir', imageUrl: 'https://randomuser.me/api/portraits/men/46.jpg', followers: 187 },
    { id: 'user4', name: 'Gizem Tekin', username: 'gizemtekin', imageUrl: 'https://randomuser.me/api/portraits/women/29.jpg', followers: 431 },
  ];
  
  // Simüle edilmiş popüler çalma listeleri
  const popularPlaylists = [
    { id: 'playlist1', name: 'Weekend Vibes', creator: 'Zeynep Kaya', imageUrl: 'https://lastfm.freetls.fastly.net/i/u/174s/6015946df4ce4ea5c6f2e3f73cef51f2.jpg', songCount: 23 },
    { id: 'playlist2', name: 'Çalışma Müzikleri', creator: 'Ahmet Yılmaz', imageUrl: 'https://lastfm.freetls.fastly.net/i/u/174s/c415e4254713a46e9bcce8ef73229abd.jpg', songCount: 35 },
    { id: 'playlist3', name: 'Relax & Chill', creator: 'Gizem Tekin', imageUrl: 'https://lastfm.freetls.fastly.net/i/u/174s/ca1d981bb7467b69d8a62c5963a3767d.jpg', songCount: 18 },
    { id: 'playlist4', name: 'Rock Classics', creator: 'Ozan Demir', imageUrl: 'https://lastfm.freetls.fastly.net/i/u/174s/fded46a153d23737c7fdc64edce1c962.jpg', songCount: 42 },
  ];
  
  // Gönderi paylaşma
  const handlePostShare = () => {
    if (post.trim()) {
      alert(`Gönderi paylaşıldı: ${post}`);
      setPost('');
    }
  };
  
  // Kullanıcı arama
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      alert(`Arama yapıldı: ${searchQuery}`);
    }
  };
  
  return (
    <div className="container mx-auto p-4 pb-24">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Müzik Topluluğu</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sol taraf - Gönderi paylaşma ve trendler */}
        <div className="md:col-span-1 space-y-6">
          {/* Gönderi paylaşma */}
          <Card>
            <CardHeader>
              <CardTitle>Şarkı Paylaş</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Avatar>
                  <AvatarImage src="https://randomuser.me/api/portraits/men/32.jpg" />
                  <AvatarFallback>AY</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <textarea
                    className="w-full border-none bg-muted p-3 rounded-md resize-none focus:outline-none"
                    placeholder="Bugün ne dinliyorsun?"
                    rows={3}
                    value={post}
                    onChange={(e) => setPost(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="flex justify-between">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <MusicIcon className="w-4 h-4 mr-1" />
                    Şarkı Ekle
                  </Button>
                </div>
                
                <Button 
                  size="sm"
                  onClick={handlePostShare}
                  disabled={!post.trim()}
                >
                  <Share2Icon className="w-4 h-4 mr-1" />
                  Paylaş
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Kullanıcı arama */}
          <Card>
            <CardHeader>
              <CardTitle>Kişi Bul</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSearch} className="flex gap-2">
                <Input
                  placeholder="Kullanıcı ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit">
                  <SearchIcon className="w-4 h-4" />
                </Button>
              </form>
            </CardContent>
          </Card>
          
          {/* Popüler kullanıcılar */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <UsersIcon className="w-5 h-5 mr-2" />
                Popüler Kullanıcılar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {popularUsers.map(user => (
                  <div key={user.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={user.imageUrl} />
                        <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <Link href={`/user/${user.id}`} className="text-sm font-medium hover:underline">
                          {user.name}
                        </Link>
                        <p className="text-xs text-muted-foreground">@{user.username}</p>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {user.followers} takipçi
                    </div>
                  </div>
                ))}
              </div>
              
              <Button variant="ghost" className="w-full mt-3 text-xs">
                Tümünü Gör
              </Button>
            </CardContent>
          </Card>
          
          {/* Popüler çalma listeleri */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUpIcon className="w-5 h-5 mr-2" />
                Popüler Çalma Listeleri
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {popularPlaylists.map(playlist => (
                  <div key={playlist.id} className="space-y-1">
                    <div className="aspect-square bg-muted rounded-md overflow-hidden">
                      <img 
                        src={playlist.imageUrl} 
                        alt={playlist.name}
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <h3 className="text-sm font-medium truncate">{playlist.name}</h3>
                    <p className="text-xs text-muted-foreground truncate">
                      {playlist.creator} • {playlist.songCount} şarkı
                    </p>
                  </div>
                ))}
              </div>
              
              <Button variant="ghost" className="w-full mt-3 text-xs">
                Tümünü Gör
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Sağ taraf - Etkinlik akışları */}
        <div className="md:col-span-2">
          <Tabs defaultValue="forYou" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="forYou">Senin İçin</TabsTrigger>
              <TabsTrigger value="following">Takip Edilenler</TabsTrigger>
              <TabsTrigger value="trending">Trendler</TabsTrigger>
            </TabsList>
            
            <TabsContent value="forYou">
              <ActivityFeed limit={5} />
            </TabsContent>
            
            <TabsContent value="following">
              <ActivityFeed limit={4} />
            </TabsContent>
            
            <TabsContent value="trending">
              <ActivityFeed limit={6} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}