import React, { useState, useEffect } from 'react';
import { useLastFmSearch } from '@/hooks/useLastFm';
import TrackItem from '@/components/music/TrackItem';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from 'lucide-react';

const Explore = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState<'track' | 'artist' | 'album'>('track');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  
  const { data: searchResults, isLoading } = useLastFmSearch(
    debouncedQuery,
    searchType,
    debouncedQuery.length > 2
  );
  
  // Update debounced query after user stops typing
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [searchQuery]);
  
  useEffect(() => {
    document.title = 'Müzik Asistanım - Keşfet';
  }, []);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setDebouncedQuery(searchQuery);
  };
  
  return (
    <div className="p-4 pb-24">
      <h1 className="text-2xl font-bold mb-6">Keşfet</h1>
      
      <Tabs defaultValue="track" onValueChange={(value) => setSearchType(value as any)}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="track">Parça</TabsTrigger>
            <TabsTrigger value="artist">Sanatçı</TabsTrigger>
            <TabsTrigger value="album">Albüm</TabsTrigger>
          </TabsList>
        </div>
        
        <form onSubmit={handleSearch} className="flex gap-2 mb-6">
          <Input
            placeholder="Müzik, sanatçı veya albüm ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
          />
          <Button type="submit">
            <Search className="w-4 h-4 mr-2" />
            Ara
          </Button>
        </form>
        
        <TabsContent value="track" className="mt-0">
          <div className="space-y-2">
            {isLoading ? (
              Array(5).fill(0).map((_, index) => (
                <div key={index} className="flex items-center gap-3 py-2 px-2 animate-pulse">
                  <div className="w-10 h-10 bg-muted rounded"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              ))
            ) : debouncedQuery.length > 2 ? (
              searchResults?.results?.trackmatches?.track?.length ? (
                searchResults.results.trackmatches.track.map((track, index) => (
                  <TrackItem 
                    key={`${track.name}-${track.artist.name}-${index}`} 
                    track={track} 
                    showAddButton={true}
                  />
                ))
              ) : (
                <p className="py-4 text-center text-muted-foreground">Parça bulunamadı. Başka bir arama deneyin.</p>
              )
            ) : (
              <p className="py-4 text-center text-muted-foreground">En az 3 karakter girerek arama yapın.</p>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="artist" className="mt-0">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {isLoading ? (
              Array(8).fill(0).map((_, index) => (
                <div key={index} className="animate-pulse">
                  <div className="bg-muted rounded-full w-full aspect-square mb-2"></div>
                  <div className="h-4 bg-muted rounded w-3/4 mx-auto mb-1"></div>
                  <div className="h-3 bg-muted rounded w-1/2 mx-auto"></div>
                </div>
              ))
            ) : debouncedQuery.length > 2 ? (
              searchResults?.results?.artistmatches?.artist?.length ? (
                searchResults.results.artistmatches.artist.map((artist, index) => (
                  <div key={index} className="text-center">
                    <div className="bg-card rounded-full w-full aspect-square overflow-hidden mb-2">
                      {artist.image?.[2]['#text'] ? (
                        <img 
                          src={artist.image[2]['#text']} 
                          alt={artist.name} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-12 h-12 text-foreground/60">
                            <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                          </svg>
                        </div>
                      )}
                    </div>
                    <h3 className="font-medium truncate">{artist.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {artist.listeners && `${parseInt(artist.listeners).toLocaleString()} dinleyici`}
                    </p>
                  </div>
                ))
              ) : (
                <p className="py-4 text-center text-muted-foreground col-span-full">Sanatçı bulunamadı. Başka bir arama deneyin.</p>
              )
            ) : (
              <p className="py-4 text-center text-muted-foreground col-span-full">En az 3 karakter girerek arama yapın.</p>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="album" className="mt-0">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {isLoading ? (
              Array(10).fill(0).map((_, index) => (
                <div key={index} className="animate-pulse">
                  <div className="bg-muted rounded-md w-full aspect-square mb-2"></div>
                  <div className="h-4 bg-muted rounded w-3/4 mb-1"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              ))
            ) : debouncedQuery.length > 2 ? (
              searchResults?.results?.albummatches?.album?.length ? (
                searchResults.results.albummatches.album.map((album, index) => (
                  <div key={index} className="bg-card rounded-lg p-3 hover:bg-secondary transition-colors cursor-pointer group">
                    <div className="mb-3 rounded-md overflow-hidden relative aspect-square">
                      {album.image?.[3]['#text'] ? (
                        <img 
                          src={album.image[3]['#text']} 
                          alt={`${album.name} by ${album.artist}`} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-10 h-10 text-foreground/60">
                            <circle cx="12" cy="12" r="10"></circle>
                            <circle cx="12" cy="12" r="3"></circle>
                          </svg>
                        </div>
                      )}
                      <button className="absolute bottom-2 right-2 w-10 h-10 bg-primary rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                        <Search className="w-5 h-5 text-white" />
                      </button>
                    </div>
                    <h3 className="font-medium text-sm mb-1 truncate">{album.name}</h3>
                    <p className="text-muted-foreground text-xs truncate">{album.artist}</p>
                  </div>
                ))
              ) : (
                <p className="py-4 text-center text-muted-foreground col-span-full">Albüm bulunamadı. Başka bir arama deneyin.</p>
              )
            ) : (
              <p className="py-4 text-center text-muted-foreground col-span-full">En az 3 karakter girerek arama yapın.</p>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Explore;
