import React, { useEffect } from 'react';
import { useTopArtists, useTopTracks, useRecommendedTracks } from '@/hooks/useLastFm';
import TrackItem from '@/components/music/TrackItem';
import AlbumCard from '@/components/music/AlbumCard';
import FeaturedArtist from '@/components/music/FeaturedArtist';
import GenreDistribution from '@/components/charts/GenreDistribution';
import WeeklyListening from '@/components/charts/WeeklyListening';
import { useMusic } from '@/contexts/MusicContext';

// Sample data for charts
const genreData = [
  { name: 'Pop', percentage: 35, color: 'hsl(var(--primary))' },
  { name: 'Rock', percentage: 25, color: 'hsl(var(--chart-3))' },
  { name: 'Hip-Hop', percentage: 15, color: 'hsl(var(--chart-2))' },
  { name: 'Electronic', percentage: 10, color: 'hsl(var(--chart-1))' },
  { name: 'Diğer', percentage: 15, color: 'hsl(var(--chart-4))' }
];

const weeklyData = [
  { day: 'Pazartesi', shortDay: 'P', percentage: 40 },
  { day: 'Salı', shortDay: 'S', percentage: 65 },
  { day: 'Çarşamba', shortDay: 'Ç', percentage: 30 },
  { day: 'Perşembe', shortDay: 'P', percentage: 80 },
  { day: 'Cuma', shortDay: 'C', percentage: 90 },
  { day: 'Cumartesi', shortDay: 'C', percentage: 75 },
  { day: 'Pazar', shortDay: 'P', percentage: 55 }
];

const Home = () => {
  const { data: topArtistsData, isLoading: isLoadingArtists } = useTopArtists();
  const { data: topTracksData, isLoading: isLoadingTracks } = useTopTracks();
  const { recommendedTracks } = useRecommendedTracks();
  const { playHistory } = useMusic();
  
  const featuredArtist = topArtistsData?.artists?.artist?.[0];
  const topTracks = topTracksData?.tracks?.track?.slice(0, 5) || [];
  
  useEffect(() => {
    document.title = 'Müzik Asistanım - Ana Sayfa';
  }, []);
  
  return (
    <div className="pb-24">
      {/* Hero Section */}
      <section className="px-4 pt-6 pb-8 relative">
        {/* Background Gradient */}
        <div className="absolute top-0 left-0 right-0 h-48 music-gradient -z-10"></div>
        
        {/* Welcome Message */}
        <div className="pb-6">
          <h1 className="text-2xl md:text-3xl font-bold mb-1">Hoş Geldin!</h1>
          <p className="text-muted-foreground">Önerilen parçaları keşfet ve yeni müzikler bul.</p>
        </div>
        
        {/* Featured Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
          {/* Featured Artist */}
          {isLoadingArtists ? (
            <div className="md:col-span-2 bg-card rounded-xl p-5 animate-pulse">
              <div className="h-36 bg-muted rounded-lg"></div>
            </div>
          ) : featuredArtist ? (
            <FeaturedArtist artist={featuredArtist} />
          ) : (
            <div className="md:col-span-2 bg-card rounded-xl p-5">
              <p className="text-muted-foreground">Şu anda öne çıkan sanatçı yok.</p>
            </div>
          )}
          
          {/* Recently Played */}
          <div className="bg-card rounded-xl shadow-lg p-5">
            <h3 className="text-lg font-semibold mb-3">Son Dinlenenler</h3>
            {/* Recently played songs list */}
            <div className="space-y-3">
              {playHistory.length > 0 ? (
                playHistory.slice(0, 3).map((track, index) => (
                  <TrackItem 
                    key={`${track.name}-${track.artist.name}-${index}`} 
                    track={track} 
                    showDuration={true}
                  />
                ))
              ) : (
                <p className="text-muted-foreground text-sm">Henüz müzik dinlemediniz.</p>
              )}
            </div>
          </div>
        </div>
      </section>
      
      {/* Recommendations Section */}
      <section className="px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Senin İçin Öneriler</h2>
          <button className="text-sm text-primary hover:text-primary/80 flex items-center">
            Tümünü Gör
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 ml-1">
              <path d="M5 12h14"></path>
              <path d="m12 5 7 7-7 7"></path>
            </svg>
          </button>
        </div>
        
        {/* Recommendation Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {recommendedTracks.length > 0 ? (
            recommendedTracks.map((track, index) => (
              <AlbumCard 
                key={`${track.name}-${track.artist.name}-${index}`} 
                album={{
                  name: track.name,
                  artist: track.artist.name,
                  url: track.url,
                  image: track.album?.image || [
                    { "#text": "", size: "small" },
                    { "#text": "", size: "medium" },
                    { "#text": "", size: "large" },
                    { "#text": "", size: "extralarge" }
                  ],
                  tracks: { track: [track] }
                }}
              />
            ))
          ) : (
            Array(5).fill(0).map((_, index) => (
              <div key={index} className="bg-card rounded-lg p-3 animate-pulse">
                <div className="aspect-square bg-muted rounded-md mb-3"></div>
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </div>
            ))
          )}
        </div>
      </section>
      
      {/* Top Charts Section */}
      <section className="px-4 py-6">
        <h2 className="text-xl font-bold mb-4">Top Listeler</h2>
        
        {/* Charts Container */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Top Tracks */}
          <div className="bg-card rounded-xl p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Bu Haftanın En İyileri</h3>
              <span className="text-xs text-muted-foreground">Last.fm'e göre</span>
            </div>
            
            {/* Top tracks list */}
            <div className="space-y-3">
              {isLoadingTracks ? (
                Array(5).fill(0).map((_, index) => (
                  <div key={index} className="flex items-center gap-3 py-1 px-2 animate-pulse">
                    <div className="text-muted-foreground w-5 text-center">{index + 1}</div>
                    <div className="w-10 h-10 bg-muted rounded"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </div>
                  </div>
                ))
              ) : (
                topTracks.map((track, index) => (
                  <TrackItem 
                    key={`${track.name}-${track.artist.name}-${index}`} 
                    track={track} 
                    index={index}
                    showAddButton={true}
                  />
                ))
              )}
            </div>
          </div>
          
          {/* Music Stats */}
          <div className="bg-card rounded-xl p-4">
            <h3 className="font-semibold mb-4">Müzik İstatistiklerin</h3>
            
            {/* Genre Distribution Chart */}
            <GenreDistribution data={genreData} />
            
            {/* Weekly Listening */}
            <WeeklyListening data={weeklyData} />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
