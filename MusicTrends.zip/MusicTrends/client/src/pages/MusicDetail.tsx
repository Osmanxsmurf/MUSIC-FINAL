import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useMusic } from '@/contexts/MusicContext';
import { getTrackInfo, getArtistInfo, getSimilarTracks } from '@/lib/lastfm-api';
import { searchYouTube } from '@/lib/youtube';
import { MusicPlayer } from '@/components/music/MusicPlayer';
import { LyricsAnalyzer } from '@/components/music/LyricsAnalyzer';
import { Card, CardContent, CardHeader, CardFooter, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { HeartIcon, Share2Icon, BookmarkIcon, PlayIcon } from '@radix-ui/react-icons';

export default function MusicDetail() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split('?')[1]);
  const songId = params.get('id');
  const songName = params.get('name');
  const artistName = params.get('artist');
  
  const [trackInfo, setTrackInfo] = useState<any>(null);
  const [artistInfo, setArtistInfo] = useState<any>(null);
  const [similarTracks, setSimilarTracks] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const { playSong } = useMusic();
  
  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      
      try {
        // Şarkı ve sanatçı bilgilerini al
        if (songName && artistName) {
          // Şarkı bilgisi
          const trackData = await getTrackInfo(artistName, songName);
          if (trackData) {
            setTrackInfo(trackData);
          }
          
          // Sanatçı bilgisi
          const artistData = await getArtistInfo(artistName);
          if (artistData) {
            setArtistInfo(artistData);
          }
          
          // Benzer şarkılar
          const similarData = await getSimilarTracks(artistName, songName);
          if (similarData) {
            setSimilarTracks(similarData);
          }
          
          // YouTube videoları
          const videoData = await searchYouTube(`${artistName} ${songName} official`, 5);
          if (videoData) {
            setVideos(videoData);
          }
        }
      } catch (error) {
        console.error('Veri getirme hatası:', error);
      } finally {
        setLoading(false);
      }
    }
    
    fetchData();
  }, [songName, artistName]);
  
  // Şarkıyı çal
  const handlePlaySong = () => {
    if (trackInfo) {
      playSong({
        id: songId || `${trackInfo.name}-${trackInfo.artist}`,
        title: trackInfo.name,
        artist: trackInfo.artist,
        imageUrl: trackInfo.imageUrl,
        duration: trackInfo.duration,
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }
  };
  
  // YouTube video oynatıcısını render et
  const renderYouTubeVideo = (videoId: string) => {
    return (
      <div className="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
          src={`https://www.youtube.com/embed/${videoId}?rel=0`}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full h-full"
        ></iframe>
      </div>
    );
  };
  
  if (loading) {
    return (
      <div className="container mx-auto p-4 pb-24 flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!trackInfo && !loading) {
    return (
      <div className="container mx-auto p-4 pb-24 flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Şarkı bulunamadı</h2>
          <p className="text-muted-foreground">Şarkı bilgileri alınamadı. Lütfen daha sonra tekrar deneyin.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-4 pb-24">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sol taraf - Şarkı bilgileri */}
        <div className="md:col-span-2">
          <div className="flex flex-col md:flex-row gap-6 mb-6">
            {/* Cover ve temel bilgiler */}
            <div className="md:w-64">
              <div className="aspect-square bg-muted rounded-xl overflow-hidden shadow-lg">
                {trackInfo?.imageUrl ? (
                  <img 
                    src={trackInfo.imageUrl} 
                    alt={trackInfo.name}
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary">Kapak yok</span>
                  </div>
                )}
              </div>
              
              <div className="flex justify-between mt-4">
                <Button variant="outline" size="icon">
                  <HeartIcon className="w-5 h-5" />
                </Button>
                <Button variant="outline" size="icon">
                  <Share2Icon className="w-5 h-5" />
                </Button>
                <Button variant="outline" size="icon">
                  <BookmarkIcon className="w-5 h-5" />
                </Button>
                <Button onClick={handlePlaySong}>
                  <PlayIcon className="w-5 h-5 mr-2" />
                  Çal
                </Button>
              </div>
            </div>
            
            {/* Şarkı detayları */}
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{trackInfo?.name}</h1>
              <h2 className="text-xl text-muted-foreground mb-4">{trackInfo?.artist}</h2>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                {trackInfo?.album && (
                  <div>
                    <span className="text-sm text-muted-foreground">Albüm</span>
                    <p>{trackInfo.album}</p>
                  </div>
                )}
                
                {trackInfo?.duration > 0 && (
                  <div>
                    <span className="text-sm text-muted-foreground">Süre</span>
                    <p>{Math.floor(trackInfo.duration / 60)}:{(trackInfo.duration % 60).toString().padStart(2, '0')}</p>
                  </div>
                )}
                
                {trackInfo?.listeners > 0 && (
                  <div>
                    <span className="text-sm text-muted-foreground">Dinleyici</span>
                    <p>{Number(trackInfo.listeners).toLocaleString()}</p>
                  </div>
                )}
                
                {trackInfo?.playcount > 0 && (
                  <div>
                    <span className="text-sm text-muted-foreground">Dinlenme</span>
                    <p>{Number(trackInfo.playcount).toLocaleString()}</p>
                  </div>
                )}
              </div>
              
              {trackInfo?.tags && trackInfo.tags.length > 0 && (
                <div className="mb-6">
                  <span className="text-sm text-muted-foreground block mb-2">Etiketler</span>
                  <div className="flex flex-wrap gap-2">
                    {trackInfo.tags.map((tag: string, index: number) => (
                      <span 
                        key={index} 
                        className="px-3 py-1 bg-muted rounded-full text-xs font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              {trackInfo?.summary && (
                <div>
                  <span className="text-sm text-muted-foreground block mb-2">Hakkında</span>
                  <p className="text-sm">{trackInfo.summary.replace(/<[^>]*>?/gm, '')}</p>
                </div>
              )}
            </div>
          </div>
          
          {/* Şarkı Sözleri ve Analiz */}
          <LyricsAnalyzer className="mb-6" />
          
          {/* Video */}
          {videos.length > 0 && (
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-4">Videolar</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {renderYouTubeVideo(videos[0].videoId)}
                
                <div className="grid grid-cols-1 gap-2">
                  {videos.slice(1, 3).map((video, index) => (
                    <div key={index} className="flex gap-2 p-2 rounded-lg hover:bg-muted transition-colors">
                      <div className="w-28 rounded-md overflow-hidden">
                        <img 
                          src={video.thumbnailUrl} 
                          alt={video.title}
                          className="w-full h-full object-cover" 
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-sm line-clamp-2">{video.title}</h3>
                        <p className="text-xs text-muted-foreground">{video.channelTitle}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Benzer Şarkılar */}
          {similarTracks.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Benzer Şarkılar</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {similarTracks.slice(0, 4).map((track, index) => (
                  <div key={index} className="bg-card hover:bg-card/90 rounded-lg p-3 transition-colors">
                    <div className="aspect-square bg-muted rounded-md mb-3 overflow-hidden">
                      {track.imageUrl ? (
                        <img 
                          src={track.imageUrl} 
                          alt={track.name}
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                          <span className="text-xs text-primary">Kapak yok</span>
                        </div>
                      )}
                    </div>
                    <h3 className="font-medium truncate">{track.name}</h3>
                    <p className="text-sm text-muted-foreground truncate">{track.artist}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Sağ taraf - Sanatçı bilgileri */}
        <div>
          {artistInfo && (
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Sanatçı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  {artistInfo.imageUrl ? (
                    <img 
                      src={artistInfo.imageUrl} 
                      alt={artistInfo.name}
                      className="w-32 h-32 rounded-full mx-auto object-cover shadow-md" 
                    />
                  ) : (
                    <div className="w-32 h-32 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                      <span className="text-primary">{artistInfo.name.charAt(0)}</span>
                    </div>
                  )}
                  <h2 className="text-xl font-bold mt-2">{artistInfo.name}</h2>
                  <div className="flex items-center justify-center gap-2 mt-1">
                    <span className="text-sm text-muted-foreground">{Number(artistInfo.listeners).toLocaleString()} dinleyici</span>
                    <span className="w-1 h-1 rounded-full bg-muted-foreground"></span>
                    <span className="text-sm text-muted-foreground">{Number(artistInfo.playcount).toLocaleString()} dinlenme</span>
                  </div>
                </div>
                
                {artistInfo.tags && artistInfo.tags.length > 0 && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium mb-2">Tarzlar</h3>
                    <div className="flex flex-wrap gap-2">
                      {artistInfo.tags.slice(0, 5).map((tag: string, index: number) => (
                        <span 
                          key={index} 
                          className="px-3 py-1 bg-muted rounded-full text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                
                {artistInfo.summary && (
                  <div className="mb-4">
                    <h3 className="text-sm font-medium mb-2">Hakkında</h3>
                    <p className="text-sm line-clamp-6">{artistInfo.summary.replace(/<[^>]*>?/gm, '')}</p>
                  </div>
                )}
                
                {artistInfo.similar && artistInfo.similar.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium mb-2">Benzer Sanatçılar</h3>
                    <div className="space-y-1.5">
                      {artistInfo.similar.slice(0, 5).map((artist: any, index: number) => (
                        <div key={index} className="flex items-center gap-2 p-1.5 rounded-md hover:bg-muted transition-colors">
                          {artist.imageUrl ? (
                            <img 
                              src={artist.imageUrl} 
                              alt={artist.name}
                              className="w-8 h-8 rounded-md object-cover" 
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center">
                              <span className="text-xs">{artist.name.charAt(0)}</span>
                            </div>
                          )}
                          <span className="text-sm truncate">{artist.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Sanatçıyı Takip Et
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}