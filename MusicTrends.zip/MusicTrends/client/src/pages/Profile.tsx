import React, { useEffect } from 'react';
import { useMusic } from '@/contexts/MusicContext';
import TrackItem from '@/components/music/TrackItem';
import GenreDistribution from '@/components/charts/GenreDistribution';
import WeeklyListening from '@/components/charts/WeeklyListening';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useTheme } from '@/contexts/ThemeContext';
import { Moon, Sun } from 'lucide-react';

// Sample data for charts
const genreData = [
  { name: 'Pop', percentage: 35, color: 'hsl(var(--primary))' },
  { name: 'Rock', percentage: 25, color: 'hsl(var(--chart-3))' },
  { name: 'Hip-Hop', percentage: 15, color: 'hsl(var(--chart-2))' },
  { name: 'Electronic', percentage: 10, color: 'hsl(var(--chart-1))' },
  { name: 'Diğer', percentage: 15, color: 'hsl(var(--chart-4))' }
];

const weeklyData = [
  { day: 'Pazartesi', shortDay: 'P', percentage: 40 },
  { day: 'Salı', shortDay: 'S', percentage: 65 },
  { day: 'Çarşamba', shortDay: 'Ç', percentage: 30 },
  { day: 'Perşembe', shortDay: 'P', percentage: 80 },
  { day: 'Cuma', shortDay: 'C', percentage: 90 },
  { day: 'Cumartesi', shortDay: 'C', percentage: 75 },
  { day: 'Pazar', shortDay: 'P', percentage: 55 }
];

const Profile = () => {
  const { playHistory, queue } = useMusic();
  const { theme, toggleTheme } = useTheme();
  
  useEffect(() => {
    document.title = 'Müzik Asistanım - Profil';
  }, []);
  
  return (
    <div className="p-4 pb-24">
      {/* Profile Header */}
      <div className="bg-card rounded-xl p-6 flex flex-col md:flex-row items-center gap-6 mb-8">
        <Avatar className="w-24 h-24 border-4 border-primary/30">
          <AvatarImage src="" />
          <AvatarFallback className="text-xl">MK</AvatarFallback>
        </Avatar>
        
        <div className="flex-1 text-center md:text-left">
          <h1 className="text-2xl font-bold mb-1">Müzik Kullanıcısı</h1>
          <p className="text-muted-foreground mb-4">Müzik tutkunuzu keşfedin ve paylaşın.</p>
          
          <div className="flex flex-wrap gap-3 justify-center md:justify-start">
            <Button variant="outline" className="gap-2">
              {playHistory.length} Dinlenme
            </Button>
            <Button variant="outline" className="gap-2">
              0 Takipçi
            </Button>
            <Button variant="outline" onClick={toggleTheme} className="gap-2">
              {theme === 'dark' ? (
                <>
                  <Moon className="w-4 h-4" />
                  Koyu Tema
                </>
              ) : (
                <>
                  <Sun className="w-4 h-4" />
                  Aydınlık Tema
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Profile Content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="md:col-span-2 space-y-6">
          {/* Recently Played */}
          <div className="bg-card rounded-xl p-4">
            <h2 className="text-xl font-bold mb-4">Son Dinlenenler</h2>
            
            <div className="space-y-2">
              {playHistory.length > 0 ? (
                playHistory.slice(0, 10).map((track, index) => (
                  <TrackItem 
                    key={`${track.name}-${track.artist.name}-${index}`} 
                    track={track} 
                    showAddButton={true}
                  />
                ))
              ) : (
                <p className="text-muted-foreground py-8 text-center">
                  Henüz hiç müzik dinlememişsiniz. Müzik keşfetmeye başlamak için arama yapabilirsiniz.
                </p>
              )}
            </div>
          </div>
          
          {/* Queue */}
          <div className="bg-card rounded-xl p-4">
            <h2 className="text-xl font-bold mb-4">Çalma Sırası</h2>
            
            <div className="space-y-2">
              {queue.length > 0 ? (
                queue.map((track, index) => (
                  <TrackItem 
                    key={`${track.name}-${track.artist.name}-${index}`} 
                    track={track} 
                    index={index}
                    showAddButton={false}
                  />
                ))
              ) : (
                <p className="text-muted-foreground py-8 text-center">
                  Çalma sıranız boş. Şarkılara tıklayarak veya "Sıraya Ekle" düğmesini kullanarak sıraya ekleyebilirsiniz.
                </p>
              )}
            </div>
          </div>
        </div>
        
        {/* Right Column */}
        <div className="space-y-6">
          {/* Music Stats */}
          <div className="bg-card rounded-xl p-4">
            <h2 className="text-xl font-bold mb-4">Müzik İstatistikleri</h2>
            
            {/* Genre Distribution Chart */}
            <GenreDistribution data={genreData} />
            
            {/* Weekly Listening */}
            <WeeklyListening data={weeklyData} />
          </div>
          
          {/* Recommended Playlists */}
          <div className="bg-card rounded-xl p-4">
            <h2 className="text-lg font-bold mb-3">Önerilen Çalma Listeleri</h2>
            
            <div className="space-y-3">
              {['En İyi Pop Şarkıları', 'Rahatlamak için Müzik', 'Enerji Veren Parçalar', 'Nostaljik Şarkılar'].map((playlist, index) => (
                <div key={index} className="flex items-center gap-3 p-2 hover:bg-secondary rounded-md transition-colors cursor-pointer">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/40 rounded-md flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
                      <path d="M9 18V5l12-2v13"></path>
                      <circle cx="6" cy="18" r="3"></circle>
                      <circle cx="18" cy="16" r="3"></circle>
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">{playlist}</h3>
                    <p className="text-xs text-muted-foreground">20 şarkı</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
