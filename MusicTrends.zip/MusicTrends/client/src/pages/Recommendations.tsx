import React, { useState, useEffect } from 'react';
import { useRecommendedTracks } from '@/hooks/useLastFm';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MoodAnalyzer } from '@/components/music/MoodAnalyzer';
import { RecommendedSongs } from '@/components/music/RecommendedSongs';
import { AVAILABLE_MOODS } from '@/lib/constants';
import { useMusic } from '@/contexts/MusicContext';
import { getTopTracksByTag } from '@/lib/lastfm-api';
import { Song } from '@/lib/data';

export default function Recommendations() {
  const [currentMood, setCurrentMood] = useState('happy');
  const [customRecommendations, setCustomRecommendations] = useState<Song[]>([]);
  const [loadingCustom, setLoadingCustom] = useState(false);
  const { playHistory } = useMusic();
  
  // Ruh haline göre önerilen şarkıları al
  const { recommendedTracks, isLoading } = useRecommendedTracks(currentMood);
  
  // Geçmiş dinlemeye göre öneriler
  useEffect(() => {
    async function getHistoryBasedRecommendations() {
      // Eğer dinleme geçmişi yoksa işlem yapma
      if (!playHistory || playHistory.length === 0) return;
      
      setLoadingCustom(true);
      
      try {
        // Son dinlenen şarkıların sanatçılarından benzersiz bir liste oluştur
        const uniqueArtists = Array.from(new Set(
          playHistory.slice(0, 5).map(track => track.artist)
        ));
        
        // İlk sanatçının türüne göre şarkı öner
        if (uniqueArtists.length > 0) {
          const artistName = uniqueArtists[0];
          // Sanatçı adı ile ilgili şarkıları getir
          const tracks = await getTopTracksByTag(artistName);
          
          if (tracks && tracks.length > 0) {
            // LastFM şarkılarını Song formatına dönüştür
            const songs: Song[] = tracks.map(track => ({
              id: `${track.name}-${track.artist}`,
              title: track.name,
              artist: track.artist,
              imageUrl: track.imageUrl,
              duration: track.duration,
              createdAt: new Date(),
              updatedAt: new Date()
            }));
            
            setCustomRecommendations(songs);
          }
        }
      } catch (error) {
        console.error('Özel öneriler alınırken hata:', error);
      } finally {
        setLoadingCustom(false);
      }
    }
    
    getHistoryBasedRecommendations();
  }, [playHistory]);
  
  // Duygu durumu değiştiğinde çağrılacak fonksiyon
  const handleMoodDetected = (mood: string) => {
    setCurrentMood(mood);
  };
  
  // Duygu durumuna göre renk belirle
  const getMoodColor = (mood: string) => {
    const colorMap: Record<string, string> = {
      'happy': 'from-yellow-400 to-orange-500',
      'sad': 'from-blue-400 to-indigo-500',
      'energetic': 'from-red-400 to-pink-500',
      'calm': 'from-green-400 to-teal-500',
      'romantic': 'from-pink-400 to-purple-500',
      'angry': 'from-red-500 to-rose-600',
      'nostalgic': 'from-purple-400 to-indigo-500'
    };
    
    return colorMap[mood] || 'from-gray-400 to-slate-500';
  };
  
  return (
    <div className="container mx-auto p-4 pb-24">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Kişiselleştirilmiş Öneriler</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Duygu durumu analizi */}
        <div className="md:col-span-1">
          <MoodAnalyzer 
            onMoodDetected={handleMoodDetected} 
            className="sticky top-24"
          />
        </div>
        
        {/* Öneriler */}
        <div className="md:col-span-2">
          <Tabs defaultValue="mood" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="mood">Duygu Durumuna Göre</TabsTrigger>
              <TabsTrigger value="history">Dinleme Geçmişine Göre</TabsTrigger>
              <TabsTrigger value="browse">Ruh Hali Kategorileri</TabsTrigger>
            </TabsList>
            
            {/* Duygu durumu tabı */}
            <TabsContent value="mood">
              <Card>
                <CardHeader>
                  <CardTitle>
                    <span className={`bg-clip-text text-transparent bg-gradient-to-r ${getMoodColor(currentMood)}`}>
                      {currentMood.charAt(0).toUpperCase() + currentMood.slice(1)} Ruh Haline Göre
                    </span>
                  </CardTitle>
                  <CardDescription>
                    Şu anki duygu durumunuza uygun müzik önerileri
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RecommendedSongs initialMood={currentMood} />
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Dinleme geçmişi tabı */}
            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle>Dinleme Geçmişinize Göre</CardTitle>
                  <CardDescription>
                    Dinlediğiniz şarkılara benzer öneriler
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingCustom ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                      {Array(4).fill(0).map((_, i) => (
                        <div key={i} className="bg-card aspect-square rounded-md animate-pulse"></div>
                      ))}
                    </div>
                  ) : customRecommendations.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                      {customRecommendations.slice(0, 8).map((song) => (
                        <div key={song.id} className="group relative overflow-hidden rounded-md aspect-square bg-muted hover:bg-muted/80 transition-colors">
                          {song.imageUrl ? (
                            <img 
                              src={song.imageUrl} 
                              alt={song.title} 
                              className="object-cover w-full h-full" 
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full">
                              <span className="text-xs text-muted-foreground">Resim yok</span>
                            </div>
                          )}
                          
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent p-3 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                            <h3 className="text-sm font-medium text-white truncate">{song.title}</h3>
                            <p className="text-xs text-gray-300 truncate">{song.artist}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">Dinleme geçmişinize göre öneri oluşturmak için önce birkaç şarkı dinleyin.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Ruh hali kategorileri tabı */}
            <TabsContent value="browse">
              <Card>
                <CardHeader>
                  <CardTitle>Ruh Haline Göre Keşfet</CardTitle>
                  <CardDescription>
                    Farklı ruh hallerine göre müzik keşfedin
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {AVAILABLE_MOODS.map((mood) => (
                      <Button
                        key={mood}
                        variant="outline"
                        className={`h-24 hover:bg-gradient-to-br ${getMoodColor(mood)} hover:text-white transition-all`}
                        onClick={() => setCurrentMood(mood)}
                      >
                        {mood.charAt(0).toUpperCase() + mood.slice(1)}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}