import React, { useState } from 'react';
import { useMusic } from '@/contexts/MusicContext';
import { VisualEqualizer, WaveVisualizer, CircleVisualizer } from '@/components/music/VisualEqualizer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { DEFAULT_COVER_URL } from '@/lib/constants';

export default function Visualizer() {
  const { currentSong, isPlaying } = useMusic();
  const [color, setColor] = useState<string>('primary');
  const [visualizerType, setVisualizerType] = useState<string>('circle');
  const [barCount, setBarCount] = useState<number>(32);
  const [size, setSize] = useState<number>(400);
  const [showInfo, setShowInfo] = useState<boolean>(true);
  
  const colors = [
    { value: 'primary', label: 'Ana Renk' },
    { value: 'blue', label: 'Mavi' },
    { value: 'green', label: 'Yeşil' },
    { value: 'purple', label: 'Mor' },
    { value: 'pink', label: 'Pembe' },
    { value: 'red', label: 'Kırmızı' },
    { value: 'orange', label: 'Turuncu' },
    { value: 'yellow', label: 'Sarı' },
    { value: 'gradient', label: 'Gradyan' }
  ];
  
  // Aktif visualizer'ı render et
  const renderVisualizer = () => {
    switch (visualizerType) {
      case 'bars':
        return <VisualEqualizer color={color} barCount={barCount} className="w-full h-72" />;
      case 'wave':
        return <WaveVisualizer color={color} height={160} className="w-full" />;
      case 'circle':
      default:
        return <CircleVisualizer color={color} size={size} className="py-6" />;
    }
  };
  
  return (
    <div className="container mx-auto p-4 pb-24">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Müzik Görselleştirici</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sol taraf - Görselleştirici ayarları */}
        <div className="bg-card rounded-xl p-6 md:col-span-1">
          <h2 className="text-xl font-semibold mb-4">Ayarlar</h2>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <Label>Görselleştirici Türü</Label>
              <Select
                value={visualizerType}
                onValueChange={setVisualizerType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Bir tür seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="circle">Dairesel</SelectItem>
                  <SelectItem value="bars">Çubuklar</SelectItem>
                  <SelectItem value="wave">Dalga</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Renk</Label>
              <Select
                value={color}
                onValueChange={setColor}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Bir renk seçin" />
                </SelectTrigger>
                <SelectContent>
                  {colors.map((color) => (
                    <SelectItem key={color.value} value={color.value}>
                      {color.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {visualizerType === 'bars' && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label>Çubuk Sayısı: {barCount}</Label>
                </div>
                <Slider
                  min={8}
                  max={64}
                  step={4}
                  value={[barCount]}
                  onValueChange={(vals) => setBarCount(vals[0])}
                />
              </div>
            )}
            
            {visualizerType === 'circle' && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label>Boyut: {size}px</Label>
                </div>
                <Slider
                  min={200}
                  max={500}
                  step={20}
                  value={[size]}
                  onValueChange={(vals) => setSize(vals[0])}
                />
              </div>
            )}
            
            <div className="flex items-center space-x-2">
              <Switch 
                checked={showInfo} 
                onCheckedChange={setShowInfo}
                id="show-info"
              />
              <Label htmlFor="show-info">Şarkı Bilgilerini Göster</Label>
            </div>
          </div>
          
          {/* Tam ekran butonu */}
          <Button className="w-full mt-6">
            Tam Ekran
          </Button>
        </div>
        
        {/* Sağ taraf - Görselleştirici */}
        <div className="md:col-span-2">
          <Card>
            <CardHeader className={!showInfo ? 'hidden' : ''}>
              <CardTitle className="flex items-center justify-between">
                <span>
                  {currentSong ? (
                    <>
                      {currentSong.title || currentSong.name || 'Bilinmeyen Şarkı'} - {currentSong.artist || 'Bilinmeyen Sanatçı'}
                    </>
                  ) : (
                    'Şu anda çalan şarkı yok'
                  )}
                </span>
                <span className="text-sm font-normal">
                  {isPlaying ? 'Çalıyor' : 'Duraklatıldı'}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center">
                {currentSong && showInfo && (
                  <div className="w-32 h-32 rounded-full overflow-hidden mb-6 ring-4 ring-primary/25">
                    <img 
                      src={currentSong.imageUrl || DEFAULT_COVER_URL}
                      alt={currentSong.title || currentSong.name || 'Album cover'}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className="w-full flex items-center justify-center">
                  {renderVisualizer()}
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Açıklama */}
          <p className="text-sm text-muted-foreground mt-4 text-center">
            Müzik çalarken görselleştirici aktifleşir. Farklı renkleri ve stilleri deneyebilirsiniz.
          </p>
        </div>
      </div>
    </div>
  );
}