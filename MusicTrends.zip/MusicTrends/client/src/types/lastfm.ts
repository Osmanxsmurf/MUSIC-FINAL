export interface LastFmImage {
  "#text": string;
  size: 'small' | 'medium' | 'large' | 'extralarge' | 'mega';
}

export interface LastFmArtist {
  name: string;
  mbid?: string;
  url: string;
  image: LastFmImage[];
  listeners?: string;
  playcount?: string;
  streamable?: string;
  similar?: {
    artist: LastFmArtist[];
  };
  tags?: {
    tag: LastFmTag[];
  };
  bio?: {
    summary: string;
    content: string;
  };
}

export interface LastFmAlbum {
  name: string;
  artist: string;
  mbid?: string;
  url: string;
  image: LastFmImage[];
  listeners?: string;
  playcount?: string;
  tracks?: {
    track: LastFmTrack[];
  };
  tags?: {
    tag: LastFmTag[];
  };
  wiki?: {
    summary: string;
    content: string;
  };
}

export interface LastFmTrack {
  name: string;
  artist: {
    name: string;
    mbid?: string;
    url: string;
  };
  album?: {
    title: string;
    mbid?: string;
    url: string;
    image: LastFmImage[];
  };
  mbid?: string;
  url: string;
  duration?: string;
  listeners?: string;
  playcount?: string;
  streamable?: {
    "#text": string;
    fulltrack: string;
  };
  similar?: {
    track: LastFmTrack[];
  };
  toptags?: {
    tag: LastFmTag[];
  };
  wiki?: {
    summary: string;
    content: string;
  };
}

export interface LastFmTag {
  name: string;
  url: string;
  count?: number;
  reach?: number;
}

export interface LastFmSearchResult {
  trackmatches?: {
    track: LastFmTrack[];
  };
  artistmatches?: {
    artist: LastFmArtist[];
  };
  albummatches?: {
    album: LastFmAlbum[];
  };
}

export interface LastFmChartTopArtists {
  artists: {
    artist: LastFmArtist[];
  };
}

export interface LastFmChartTopTracks {
  tracks: {
    track: LastFmTrack[];
  };
}

export interface LastFmApiResponse<T> {
  results?: T;
  artist?: LastFmArtist;
  album?: LastFmAlbum;
  track?: LastFmTrack;
  artists?: { artist: LastFmArtist[] };
  albums?: { album: LastFmAlbum[] };
  tracks?: { track: LastFmTrack[] };
  error?: number;
  message?: string;
}
