import { LastFmTrack } from "./lastfm";

// Song tipi, hem Last.fm track hem de custom song implementasyonunu kapsayacak şekilde
export interface Song {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  imageUrl?: string;
  youtubeId?: string;
}

// Last.fm Track'ten Song tipine dönüştürme
export function convertLastFmTrackToSong(track: LastFmTrack): Song {
  return {
    id: track.mbid || `${track.artist.name}-${track.name}`,
    title: track.name,
    artist: track.artist.name,
    album: track.album?.title,
    duration: track.duration ? parseInt(track.duration) : undefined,
    imageUrl: track.album?.image?.find(img => img.size === 'large')?.["#text"] || '',
    youtubeId: undefined
  };
}