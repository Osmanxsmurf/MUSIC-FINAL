import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

// API endpoints for the Last.fm and YouTube integration
export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // Last.fm API proxy routes
  app.get('/api/lastfm/search', async (req, res) => {
    try {
      const { query, type = 'track' } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: 'Query parameter is required' });
      }
      
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const method = `${type}.search`;
      const url = `https://ws.audioscrobbler.com/2.0/?method=${method}&${type}=${encodeURIComponent(query as string)}&api_key=${apiKey}&format=json`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error searching Last.fm:', error);
      res.status(500).json({ message: 'Failed to search Last.fm' });
    }
  });

  app.get('/api/lastfm/top-tracks', async (req, res) => {
    try {
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const url = `https://ws.audioscrobbler.com/2.0/?method=chart.getTopTracks&api_key=${apiKey}&format=json&limit=10`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting top tracks from Last.fm:', error);
      res.status(500).json({ message: 'Failed to get top tracks' });
    }
  });

  app.get('/api/lastfm/top-artists', async (req, res) => {
    try {
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const url = `https://ws.audioscrobbler.com/2.0/?method=chart.getTopArtists&api_key=${apiKey}&format=json&limit=10`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting top artists from Last.fm:', error);
      res.status(500).json({ message: 'Failed to get top artists' });
    }
  });

  app.get('/api/lastfm/artist-info', async (req, res) => {
    try {
      const { artist } = req.query;
      
      if (!artist) {
        return res.status(400).json({ message: 'Artist parameter is required' });
      }
      
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const url = `https://ws.audioscrobbler.com/2.0/?method=artist.getInfo&artist=${encodeURIComponent(artist as string)}&api_key=${apiKey}&format=json`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting artist info from Last.fm:', error);
      res.status(500).json({ message: 'Failed to get artist info' });
    }
  });

  app.get('/api/lastfm/album-info', async (req, res) => {
    try {
      const { artist, album } = req.query;
      
      if (!artist || !album) {
        return res.status(400).json({ message: 'Artist and album parameters are required' });
      }
      
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const url = `https://ws.audioscrobbler.com/2.0/?method=album.getInfo&artist=${encodeURIComponent(artist as string)}&album=${encodeURIComponent(album as string)}&api_key=${apiKey}&format=json`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting album info from Last.fm:', error);
      res.status(500).json({ message: 'Failed to get album info' });
    }
  });

  app.get('/api/lastfm/track-info', async (req, res) => {
    try {
      const { artist, track } = req.query;
      
      if (!artist || !track) {
        return res.status(400).json({ message: 'Artist and track parameters are required' });
      }
      
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const url = `https://ws.audioscrobbler.com/2.0/?method=track.getInfo&artist=${encodeURIComponent(artist as string)}&track=${encodeURIComponent(track as string)}&api_key=${apiKey}&format=json`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting track info from Last.fm:', error);
      res.status(500).json({ message: 'Failed to get track info' });
    }
  });

  app.get('/api/lastfm/similar-tracks', async (req, res) => {
    try {
      const { artist, track } = req.query;
      
      if (!artist || !track) {
        return res.status(400).json({ message: 'Artist and track parameters are required' });
      }
      
      const apiKey = process.env.LASTFM_API_KEY || 'ed0f28ee6e2da02b1796c1bce3d85535';
      const url = `https://ws.audioscrobbler.com/2.0/?method=track.getSimilar&artist=${encodeURIComponent(artist as string)}&track=${encodeURIComponent(track as string)}&api_key=${apiKey}&format=json&limit=10`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting similar tracks from Last.fm:', error);
      res.status(500).json({ message: 'Failed to get similar tracks' });
    }
  });

  // YouTube API proxy routes
  app.get('/api/youtube/search', async (req, res) => {
    try {
      const { query } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: 'Query parameter is required' });
      }
      
      const apiKey = process.env.YOUTUBE_API_KEY || 'AIzaSyAzqsXjoQCFDi5c5Lf6Ilp9det-5lS5QCg';
      const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=5&q=${encodeURIComponent(query as string)}&type=video&key=${apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error searching YouTube:', error);
      res.status(500).json({ message: 'Failed to search YouTube' });
    }
  });

  app.get('/api/youtube/video-details', async (req, res) => {
    try {
      const { videoId } = req.query;
      
      if (!videoId) {
        return res.status(400).json({ message: 'Video ID parameter is required' });
      }
      
      const apiKey = process.env.YOUTUBE_API_KEY || 'AIzaSyAzqsXjoQCFDi5c5Lf6Ilp9det-5lS5QCg';
      const url = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${videoId}&key=${apiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      res.json(data);
    } catch (error) {
      console.error('Error getting YouTube video details:', error);
      res.status(500).json({ message: 'Failed to get video details' });
    }
  });

  // Playlists routes
  app.get('/api/playlists', async (req, res) => {
    try {
      const playlists = await storage.getPlaylists();
      res.json(playlists);
    } catch (error) {
      console.error('Error getting playlists:', error);
      res.status(500).json({ message: 'Failed to get playlists' });
    }
  });

  app.post('/api/playlists', async (req, res) => {
    try {
      const { name, tracks = [] } = req.body;
      
      if (!name) {
        return res.status(400).json({ message: 'Playlist name is required' });
      }
      
      const playlist = await storage.createPlaylist({ name, tracks });
      res.status(201).json(playlist);
    } catch (error) {
      console.error('Error creating playlist:', error);
      res.status(500).json({ message: 'Failed to create playlist' });
    }
  });

  app.put('/api/playlists/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const { name, tracks } = req.body;
      
      if (!id) {
        return res.status(400).json({ message: 'Playlist ID is required' });
      }
      
      const playlist = await storage.updatePlaylist(parseInt(id), { name, tracks });
      
      if (!playlist) {
        return res.status(404).json({ message: 'Playlist not found' });
      }
      
      res.json(playlist);
    } catch (error) {
      console.error('Error updating playlist:', error);
      res.status(500).json({ message: 'Failed to update playlist' });
    }
  });

  app.delete('/api/playlists/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      if (!id) {
        return res.status(400).json({ message: 'Playlist ID is required' });
      }
      
      const success = await storage.deletePlaylist(parseInt(id));
      
      if (!success) {
        return res.status(404).json({ message: 'Playlist not found' });
      }
      
      res.json({ message: 'Playlist deleted successfully' });
    } catch (error) {
      console.error('Error deleting playlist:', error);
      res.status(500).json({ message: 'Failed to delete playlist' });
    }
  });

  return httpServer;
}
