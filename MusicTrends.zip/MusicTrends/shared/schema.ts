import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  avatarUrl: text("avatar_url"),
  createdAt: text("created_at").notNull().default(new Date().toISOString()),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  avatarUrl: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Playlist model
export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").references(() => users.id),
  tracks: jsonb("tracks").notNull().default([]),
  createdAt: text("created_at").notNull().default(new Date().toISOString()),
  updatedAt: text("updated_at").notNull().default(new Date().toISOString()),
});

export const insertPlaylistSchema = createInsertSchema(playlists).pick({
  name: true,
  userId: true,
  tracks: true,
});

export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type Playlist = typeof playlists.$inferSelect;

// PlayHistory model to track listening history
export const playHistory = pgTable("play_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  trackData: jsonb("track_data").notNull(),
  playedAt: text("played_at").notNull().default(new Date().toISOString()),
});

export const insertPlayHistorySchema = createInsertSchema(playHistory).pick({
  userId: true,
  trackData: true,
});

export type InsertPlayHistory = z.infer<typeof insertPlayHistorySchema>;
export type PlayHistory = typeof playHistory.$inferSelect;

// Custom Track type from Last.fm for both client and server use
export const lastFmTrackSchema = z.object({
  name: z.string(),
  artist: z.object({
    name: z.string(),
    mbid: z.string().optional(),
    url: z.string().optional(),
  }),
  album: z.object({
    title: z.string().optional(),
    mbid: z.string().optional(),
    url: z.string().optional(),
    image: z.array(
      z.object({
        "#text": z.string(),
        size: z.enum(["small", "medium", "large", "extralarge", "mega"]),
      })
    ).optional(),
  }).optional(),
  mbid: z.string().optional(),
  url: z.string().optional(),
  duration: z.string().optional(),
  listeners: z.string().optional(),
  playcount: z.string().optional(),
  youtubeId: z.string().optional(),
});

export type LastFmTrack = z.infer<typeof lastFmTrackSchema>;

// Schema extend storage interface for playlists
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Playlist methods
  getPlaylists(): Promise<Playlist[]>;
  getPlaylistById(id: number): Promise<Playlist | undefined>;
  createPlaylist(playlist: Omit<InsertPlaylist, 'userId'>): Promise<Playlist>;
  updatePlaylist(id: number, updates: Partial<Omit<InsertPlaylist, 'userId'>>): Promise<Playlist | undefined>;
  deletePlaylist(id: number): Promise<boolean>;
  
  // Play history methods
  addToPlayHistory(trackData: LastFmTrack): Promise<PlayHistory>;
  getPlayHistory(limit?: number): Promise<PlayHistory[]>;
}
